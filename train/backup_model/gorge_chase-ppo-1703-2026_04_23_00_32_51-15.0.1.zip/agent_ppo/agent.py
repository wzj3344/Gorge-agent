#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Agent class for Gorge Chase PPO.
峡谷追猎 PPO Agent 主类。
"""

import torch

torch.set_num_threads(1)
torch.set_num_interop_threads(1)

import numpy as np
from kaiwudrl.interface.agent import BaseAgent

from agent_ppo.algorithm.algorithm import Algorithm
from agent_ppo.conf.conf import Config
from agent_ppo.feature.definition import ActData, ObsData
from agent_ppo.feature.preprocessor import Preprocessor
from agent_ppo.model.model import Model


class Agent(BaseAgent):
    def __init__(self, agent_type="player", device=None, logger=None, monitor=None):
        torch.manual_seed(0)
        self.device = device
        self.model = Model(device).to(self.device)
        self.optimizer = torch.optim.Adam(
            params=self.model.parameters(),
            lr=Config.INIT_LEARNING_RATE_START,
            betas=(0.9, 0.999),
            eps=1e-8,
        )
        self.algorithm = Algorithm(self.model, self.optimizer, self.device, logger, monitor)
        self.preprocessor = Preprocessor()
        self.last_action = -1
        self.logger = logger
        self.monitor = monitor
        super().__init__(agent_type, device, logger, monitor)

    def reset(self, env_obs=None):
        """Reset per-episode state.

        每局开始时重置状态。
        """
        self.preprocessor.reset()
        self.last_action = -1

    def observation_process(self, env_obs):
        """Convert raw env_obs to ObsData and remain_info.

        将原始观测转换为 ObsData 和 remain_info。
        """
        feature, legal_action, reward = self.preprocessor.feature_process(env_obs, self.last_action)
        obs_data = ObsData(
            feature=list(feature),
            legal_action=legal_action,
        )
        remain_info = {"reward": reward}
        return obs_data, remain_info

    def predict(self, list_obs_data):
        """Stochastic inference for training (exploration).

        训练时随机采样动作（探索）。
        """
        feature = list_obs_data[0].feature
        legal_action = list_obs_data[0].legal_action

        logits, value, prob = self._run_model(feature, legal_action)

        # Ensure probability vector is finite and normalized before sampling.
        if (not np.all(np.isfinite(prob))) or float(np.sum(prob)) <= 0.0:
            prob = self._legal_fallback_distribution(np.asarray(legal_action, dtype=np.float64))

        try:
            action = self._legal_sample(prob, use_max=False)
        except Exception as err:
            if self.logger:
                self.logger.warning(f"stochastic sampling failed, fallback to greedy: {err}")
            action = self._legal_sample(prob, use_max=True)

        d_action = self._legal_sample(prob, use_max=True)

        return [
            ActData(
                action=[action],
                d_action=[d_action],
                prob=list(prob),
                value=value,
            )
        ]

    def exploit(self, env_obs):
        """Greedy inference for evaluation.

        评估时贪心选择动作（利用）。
        """
        obs_data, _ = self.observation_process(env_obs)
        act_data = self.predict([obs_data])
        return self.action_process(act_data[0], is_stochastic=False)

    def learn(self, list_sample_data):
        """Train the model.

        训练模型。
        """
        return self.algorithm.learn(list_sample_data)

    def save_model(self, path=None, id="1"):
        """Save model checkpoint.

        保存模型检查点。
        """
        model_file_path = f"{path}/model.ckpt-{str(id)}.pkl"
        state_dict_cpu = {k: v.clone().cpu() for k, v in self.model.state_dict().items()}
        torch.save(state_dict_cpu, model_file_path)
        self.logger.info(f"save model {model_file_path} successfully")

    def load_model(self, path=None, id="1"):
        """Load model checkpoint.

        加载模型检查点。
        """
        model_file_path = f"{path}/model.ckpt-{str(id)}.pkl"
        self.model.load_state_dict(torch.load(model_file_path, map_location=self.device))
        self.logger.info(f"load model {model_file_path} successfully")

    def action_process(self, act_data, is_stochastic=True):
        """Unpack ActData to int action and update last_action.

        解包 ActData 为 int 动作并记录 last_action。
        """
        action = act_data.action if is_stochastic else act_data.d_action
        self.last_action = int(action[0])
        return int(action[0])

    def _run_model(self, feature, legal_action):
        """Run model inference, return logits, value, prob.

        执行模型推理，返回 logits、value 和动作概率。
        """
        self.model.set_eval_mode()
        obs_tensor = torch.tensor(np.array([feature]), dtype=torch.float32).to(self.device)

        with torch.no_grad():
            logits, value = self.model(obs_tensor, inference=True)

        logits_np = logits.cpu().numpy()[0]
        value_np = value.cpu().numpy()[0]

        # Legal action masked softmax / 合法动作掩码 softmax
        legal_action_np = np.array(legal_action, dtype=np.float32)
        prob = self._legal_soft_max(logits_np, legal_action_np)

        return logits_np, value_np, prob

    def _legal_fallback_distribution(self, legal_action):
        """Build a safe fallback distribution over legal actions.

        构建安全兜底分布：优先均匀分配到合法动作。
        """
        legal_action = np.asarray(legal_action, dtype=np.float64)
        finite_mask = np.isfinite(legal_action)
        legal_action = np.where(finite_mask, legal_action, 0.0)
        hard_mask = legal_action > Config.SOFT_ACTION_EPS
        fallback = hard_mask.astype(np.float64)
        fallback_sum = float(np.sum(fallback))
        if fallback_sum <= 0.0:
            fallback = np.ones_like(legal_action, dtype=np.float64)
            fallback_sum = float(np.sum(fallback))
        return fallback / fallback_sum

    def _legal_soft_max(self, input_hidden, legal_action):
        """Softmax with legal action masking (numpy).

        合法动作掩码下的 softmax（numpy 版）。
        """
        legal_action = np.asarray(legal_action, dtype=np.float64)
        input_hidden = np.asarray(input_hidden, dtype=np.float64)

        if (not np.all(np.isfinite(legal_action))) or (not np.all(np.isfinite(input_hidden))):
            return self._legal_fallback_distribution(legal_action)

        hard_mask = legal_action > Config.SOFT_ACTION_EPS
        soft_weight = np.clip(legal_action, Config.SOFT_ACTION_EPS, 1.0)
        soft_bias = np.log(soft_weight)
        masked_logits = input_hidden + soft_bias
        masked_logits = np.where(hard_mask, masked_logits, -1e20)

        tmp_max = np.max(masked_logits, keepdims=True)
        if not np.all(np.isfinite(tmp_max)):
            return self._legal_fallback_distribution(legal_action)

        exp_logits = np.exp(np.clip(masked_logits - tmp_max, -60.0, 60.0)) * hard_mask.astype(np.float64)
        prob = np.asarray(exp_logits, dtype=np.float64)

        prob = np.clip(prob, 0.0, None)
        s = float(np.sum(prob))
        if (not np.isfinite(s)) or s <= 0.0:
            return self._legal_fallback_distribution(legal_action)
        prob /= s

        # Lightweight tail correction to pass strict probability checks.
        prob = np.clip(prob, 0.0, None)
        s = float(np.sum(prob))
        if (not np.isfinite(s)) or s <= 0.0:
            return self._legal_fallback_distribution(legal_action)
        prob /= s

        prob[np.abs(prob) < 1e-15] = 0.0
        s = float(np.sum(prob))
        if (not np.isfinite(s)) or s <= 0.0:
            return self._legal_fallback_distribution(legal_action)
        prob /= s

        return prob

    def _legal_sample(self, probs, use_max=False):
        """Sample action from probability distribution.

        按概率分布采样动作。
        """
        probs = np.asarray(probs, dtype=np.float64).reshape(-1)
        probs = np.clip(probs, 0.0, None)

        total = float(np.sum(probs))
        if (not np.isfinite(total)) or total <= 0.0:
            raise ValueError("invalid probability sum in _legal_sample")
        probs /= total

        if use_max:
            return int(np.argmax(probs))
        return int(np.random.choice(probs.shape[0], p=probs))

#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright (c) 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Feature preprocessor and reward design for Gorge Chase PPO.
"""

import math
from collections import deque

import numpy as np

from agent_ppo.conf.conf import Config

MAX_MONSTER_SPEED = 5.0
MAX_BUFF_DURATION = 500.0
MAP_SIZE = float(Config.GLOBAL_MAP_SIZE)
NEG_INF_VISIT = -10**9
FLASH_RANGE = np.array([10.0, 8.0, 10.0, 8.0, 10.0, 8.0, 10.0, 8.0], dtype=np.float32)

# 方向顺序与动作严格对齐：右、右上、上、左上、左、左下、下、右下。
FLASH_DIR_RC = [(0, 1), (-1, 1), (-1, 0), (-1, -1), (0, -1), (1, -1), (1, 0), (1, 1)]
FLASH_DIR_XZ = [(1.0, 0.0), (1.0, 1.0), (0.0, 1.0), (-1.0, 1.0), (-1.0, 0.0), (-1.0, -1.0), (0.0, -1.0), (1.0, -1.0)]
DIR_MAP = {
    0: (0.0, 0.0),
    1: (1.0, 0.0),
    2: (0.707, 0.707),
    3: (0.0, 1.0),
    4: (-0.707, 0.707),
    5: (-1.0, 0.0),
    6: (-0.707, -0.707),
    7: (0.0, -1.0),
    8: (0.707, -0.707),
}
MOVE_DIR_UNIT = np.array(
    [np.array(direction, dtype=np.float32) / max(np.linalg.norm(direction), 1e-6) for direction in FLASH_DIR_XZ],
    dtype=np.float32,
)


def _norm(v, v_max, v_min=0.0):
    v = float(np.clip(v, v_min, v_max))
    return (v - v_min) / (v_max - v_min) if (v_max - v_min) > 1e-6 else 0.0


class Preprocessor:
    def __init__(self):
        self.reset()

    def reset(self):
        self.step_no = 0
        self.max_step = Config.DEFAULT_MAX_STEP
        self.last_min_monster_dist_raw_visible = None
        self.last_min_monster_dist_raw_all = None
        self.last_hero_pos = None
        self.last_score = 0.0
        self.last_buff_time = 0.0
        self.last_treasures = 0
        self.last_buffs = 0

        self.prev_flash_dir_reachable_ratio = np.zeros(8, dtype=np.float32)
        self.prev_flash_dir_cross_wall_flag = np.zeros(8, dtype=np.float32)
        self.prev_flash_dir_actual_range = np.ones(8, dtype=np.float32)
        self.prev_flash_dir_path_resource_gain = np.zeros(8, dtype=np.float32)
        self.prev_survive_pressure_score = 0.0
        self.prev_flash_decision_pressure = 0.0
        self.prev_local_open_score = 0.0
        self.prev_selected_flash_range = 1.0
        self.prev_target_buff_value_score = 0.0
        self.prev_target_resource_exists = False
        self.prev_target_resource_sub_type = 0
        self.prev_target_resource_dist_norm = 1.0
        self.prev_target_resource_dir_vec = np.zeros(2, dtype=np.float32)
        self.prev_flash_target_overshoot_risk = np.zeros(8, dtype=np.float32)
        self.prev_raw_threat_score = 0.0
        self.prev_effective_pressure_score = 0.0
        self.prev_min_monster_reach_time_visible = float(Config.LOCAL_UNREACHABLE_TIME_CAP)
        self.prev_min_monster_reach_time_all = float(Config.LOCAL_UNREACHABLE_TIME_CAP)
        self.prev_min_monster_reach_dist_visible = float(Config.LOCAL_UNREACHABLE_DIST_CAP)
        self.prev_min_monster_reach_dist_all = float(Config.LOCAL_UNREACHABLE_DIST_CAP)
        self.prev_target_walk_reachable = False
        self.prev_target_flash_reachable = False
        self.prev_target_path_dist_norm = 1.0
        self.prev_target_line_blocked = 0.0
        self.prev_explore_dir_gain = np.zeros(8, dtype=np.float32)
        self.prev_new_visible_unknown_ratio = 0.0
        self.recent_positions_long = deque(maxlen=max(Config.PATH_EFF_WINDOW, Config.LOOP_CLOSE_MID) + 1)
        self.recent_step_distances = deque(maxlen=max(Config.PATH_EFF_WINDOW, Config.LOOP_CLOSE_MID))
        self.prev_target_buff_exists = False
        self.prev_target_buff_key = None
        self.prev_target_buff_dist_norm = 1.0
        self.prev_target_buff_ready_score = 0.0
        self.prev_target_treasure_exists = False
        self.prev_target_treasure_key = None
        self.prev_target_treasure_path_dist_norm = 1.0
        self.prev_treasure_guidance_exists = False
        self.prev_treasure_guidance_dist_norm = 1.0
        self.prev_treasure_guidance_key = None
        self.progress_short_hist = deque(maxlen=Config.STALL_SHORT_WINDOW)
        self.progress_mid_hist = deque(maxlen=Config.STALL_MID_WINDOW)
        self.prev_dir_progress_scores = np.zeros(8, dtype=np.float32)
        self._latest_dir_explore_gain = np.zeros(8, dtype=np.float32)
        self._latest_dir_resource_progress = np.zeros(8, dtype=np.float32)
        self._latest_dir_topology_gain = np.zeros(8, dtype=np.float32)

        self.global_terrain = np.full((Config.GLOBAL_MAP_SIZE, Config.GLOBAL_MAP_SIZE), -1, dtype=np.int8)
        self.global_visit = np.zeros((Config.GLOBAL_MAP_SIZE, Config.GLOBAL_MAP_SIZE), dtype=np.int32)
        self.global_last_visit = np.full(
            (Config.GLOBAL_MAP_SIZE, Config.GLOBAL_MAP_SIZE), NEG_INF_VISIT, dtype=np.int32
        )
        self.global_buff_mask = np.zeros((Config.GLOBAL_MAP_SIZE, Config.GLOBAL_MAP_SIZE), dtype=np.int8)
        self.global_buff_cd = np.zeros((Config.GLOBAL_MAP_SIZE, Config.GLOBAL_MAP_SIZE), dtype=np.int32)

        self.recent_positions = deque(maxlen=Config.LOOP_WINDOW)
        self.recent_positions_region = deque(maxlen=Config.REGION_LOOP_WINDOW)
        self.prev_active_buff_points = set()

    def _safe_int(self, value, default=-1):
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    def _pick_runtime_value(self, env_info, keys, default, positive_only=False):
        value = default
        for key in keys:
            if key in env_info and env_info[key] is not None:
                value = env_info[key]
                break
        try:
            value = int(value) if isinstance(default, int) else float(value)
        except (TypeError, ValueError):
            value = default
        if positive_only and value <= 0:
            return default
        return value

    def _get_runtime_cfg(self, env_info):
        return {
            "treasure_count": self._pick_runtime_value(
                env_info, ["treasure_count", "total_treasure"], Config.DEFAULT_TREASURE_COUNT
            ),
            "buff_count": self._pick_runtime_value(
                env_info, ["buff_count", "total_buff"], Config.DEFAULT_BUFF_COUNT
            ),
            "buff_cooldown": self._pick_runtime_value(
                env_info, ["buff_cooldown"], Config.DEFAULT_BUFF_COOLDOWN, positive_only=True
            ),
            "talent_cooldown": self._pick_runtime_value(
                env_info, ["talent_cooldown", "flash_cooldown"], Config.DEFAULT_TALENT_COOLDOWN, positive_only=True
            ),
            "monster_interval": self._pick_runtime_value(
                env_info, ["monster_interval"], Config.DEFAULT_MONSTER_INTERVAL, positive_only=True
            ),
            "monster_speedup": self._pick_runtime_value(
                env_info, ["monster_speedup"], Config.DEFAULT_MONSTER_SPEEDUP, positive_only=True
            ),
            "max_step": self._pick_runtime_value(
                env_info, ["max_step"], Config.DEFAULT_MAX_STEP, positive_only=True
            ),
        }

    def _is_passable(self, map_info, row, col):
        return (
            map_info is not None
            and row >= 0
            and col >= 0
            and row < len(map_info)
            and col < len(map_info[0])
            and map_info[row][col] != 0
        )

    def _clip_global_coord(self, value):
        return int(np.clip(round(float(value)), 0, Config.GLOBAL_MAP_SIZE - 1))

    def _get_grid_pos(self, pos):
        return self._clip_global_coord(pos["x"]), self._clip_global_coord(pos["z"])

    def _estimate_bucket_distance(self, bucket):
        return float(bucket) * 30.0 + 15.0

    def _distance_pos(self, pos_a, pos_b):
        return math.sqrt((pos_a["x"] - pos_b["x"]) ** 2 + (pos_a["z"] - pos_b["z"]) ** 2)

    def _estimate_entity_pos_from_relative(self, hero_pos, direction, bucket):
        dir_vec = DIR_MAP.get(direction, (0.0, 0.0))
        est_dist = self._estimate_bucket_distance(bucket)
        return {"x": hero_pos["x"] + dir_vec[0] * est_dist, "z": hero_pos["z"] + dir_vec[1] * est_dist}

    def _point_to_segment_distance(self, point, seg_start, seg_end):
        sx, sz = seg_end["x"] - seg_start["x"], seg_end["z"] - seg_start["z"]
        seg_len_sq = sx * sx + sz * sz
        if seg_len_sq <= 1e-6:
            return self._distance_pos(point, seg_start)
        px, pz = point["x"] - seg_start["x"], point["z"] - seg_start["z"]
        proj = float(np.clip((px * sx + pz * sz) / seg_len_sq, 0.0, 1.0))
        closest = {"x": seg_start["x"] + proj * sx, "z": seg_start["z"] + proj * sz}
        return self._distance_pos(point, closest)

    def _find_flash_landing(self, map_info, center, dir_rc, flash_range):
        if map_info is None or center is None:
            return 0, center, False
        dr, dc = dir_rc
        landing_step, landing_cell = 0, center
        for step in range(int(flash_range), 0, -1):
            row, col = center[0] + dr * step, center[1] + dc * step
            if self._is_passable(map_info, row, col):
                landing_step, landing_cell = step, (row, col)
                break

        crossed_wall = False
        for step in range(1, landing_step):
            row, col = center[0] + dr * step, center[1] + dc * step
            if not self._is_passable(map_info, row, col):
                crossed_wall = True
                break
        return landing_step, landing_cell, crossed_wall

    def _compute_landing_open_score(self, map_info, landing_cell):
        if map_info is None or landing_cell is None:
            return 0.0
        radius = Config.FLASH_LANDING_WINDOW_RADIUS
        total_count = float((2 * radius + 1) ** 2)
        passable_count = 0.0
        for dr in range(-radius, radius + 1):
            for dc in range(-radius, radius + 1):
                if self._is_passable(map_info, landing_cell[0] + dr, landing_cell[1] + dc):
                    passable_count += 1.0
        return float(passable_count / max(total_count, 1.0))

    def _count_resources_on_flash_path(self, organs, hero_pos, landing_pos, treasure_count_cfg, buff_count_cfg):
        if organs is None:
            return 0.0

        n_treasure, n_buff = 0.0, 0.0
        for organ in organs:
            if organ.get("status", 1) != 1:
                continue
            organ_pos = organ.get("pos")
            if not isinstance(organ_pos, dict) or "x" not in organ_pos or "z" not in organ_pos:
                organ_pos = self._estimate_entity_pos_from_relative(
                    hero_pos, organ.get("hero_relative_direction", 0), organ.get("hero_l2_distance", 5)
                )
            if self._point_to_segment_distance(organ_pos, hero_pos, landing_pos) > 1.25:
                continue
            if organ.get("sub_type") == 1:
                n_treasure += 1.0
            elif organ.get("sub_type") == 2:
                n_buff += 1.0

        return float(
            Config.FLASH_PATH_TREASURE_WEIGHT * n_treasure / max(float(treasure_count_cfg), 1.0)
            + Config.FLASH_PATH_BUFF_WEIGHT * n_buff / max(float(buff_count_cfg), 1.0)
        )

    def _compute_flash_direction_features(
        self,
        map_info,
        hero_pos,
        monsters,
        organs,
        runtime_cfg,
        time_to_monster2_ratio,
        time_to_monster_speedup_ratio,
        is_flash_avail,
        has_buff,
        current_flash_decision_pressure,
    ):
        reachable_ratio = np.zeros(8, dtype=np.float32)
        cross_wall_flag = np.zeros(8, dtype=np.float32)
        landing_open_score = np.zeros(8, dtype=np.float32)
        landing_dead_end_risk = np.zeros(8, dtype=np.float32)
        safe_gain = np.zeros(8, dtype=np.float32)
        path_resource_gain = np.zeros(8, dtype=np.float32)
        actual_range = np.ones(8, dtype=np.float32)

        center = None
        if map_info is not None and len(map_info) > 0 and len(map_info[0]) > 0:
            center = (len(map_info) // 2, len(map_info[0]) // 2)

        for idx in range(8):
            flash_range = FLASH_RANGE[idx]
            landing_step, landing_cell, crossed_wall = self._find_flash_landing(map_info, center, FLASH_DIR_RC[idx], flash_range)
            reachable_ratio[idx] = float(landing_step / max(flash_range, 1.0))
            cross_wall_flag[idx] = float(crossed_wall and reachable_ratio[idx] >= Config.FLASH_CROSS_MIN_REACHABLE_RATIO)
            actual_range[idx] = float(max(landing_step, 1))

            landing_open = self._compute_landing_open_score(map_info, landing_cell)
            landing_open_score[idx] = float(landing_open)
            landing_dead_end_risk[idx] = float(1.0 - landing_open)

            landing_pos = self._local_cell_to_world_pos(hero_pos, landing_cell[0], landing_cell[1], map_info)
            landing_reach_metrics = self._compute_min_monster_reach_metrics(
                map_info=map_info,
                hero_pos=landing_pos,
                monsters=monsters,
                map_anchor_pos=hero_pos,
            )
            landing_open_local = self._compute_cell_open_score(map_info, landing_cell)
            _, landing_flash_pressure, _ = self._compute_pressure_scores_v2(
                min_reach_time_visible=landing_reach_metrics["min_reach_time_visible"],
                min_reach_time_all=landing_reach_metrics["min_reach_time_all"],
                monsters=monsters,
                time_to_monster2_ratio=time_to_monster2_ratio,
                time_to_monster_speedup_ratio=time_to_monster_speedup_ratio,
                local_open_score=landing_open_local,
                is_flash_avail=is_flash_avail,
                has_buff=has_buff,
                runtime_cfg=runtime_cfg,
            )
            safe_gain[idx] = float(np.clip(current_flash_decision_pressure - landing_flash_pressure, -1.0, 1.0))
            path_resource_gain[idx] = self._count_resources_on_flash_path(
                organs, hero_pos, landing_pos, runtime_cfg["treasure_count"], runtime_cfg["buff_count"]
            )

        return {
            "feature": np.concatenate(
                [
                    reachable_ratio,
                    cross_wall_flag,
                    landing_open_score,
                    landing_dead_end_risk,
                    safe_gain,
                    path_resource_gain,
                ]
            ).astype(np.float32),
            "reachable_ratio": reachable_ratio,
            "cross_wall_flag": cross_wall_flag,
            "landing_open_score": landing_open_score,
            "safe_gain": safe_gain,
            "path_resource_gain": path_resource_gain,
            "actual_range": actual_range,
        }

    def _update_global_maps(self, hero_pos, map_info, organs, runtime_cfg):
        self.global_buff_cd[self.global_buff_cd > 0] -= 1

        if map_info is not None and len(map_info) > 0 and len(map_info[0]) > 0:
            hero_x, hero_z = self._get_grid_pos(hero_pos)
            center_row = len(map_info) // 2
            center_col = len(map_info[0]) // 2
            for row in range(len(map_info)):
                for col in range(len(map_info[0])):
                    gx = hero_x + (col - center_col)
                    gz = hero_z - (row - center_row)
                    if 0 <= gx < Config.GLOBAL_MAP_SIZE and 0 <= gz < Config.GLOBAL_MAP_SIZE:
                        self.global_terrain[gx, gz] = 0 if map_info[row][col] == 0 else 1

        observed_active_points = set()
        observed_inactive_points = set()
        for organ in organs or []:
            if organ.get("sub_type") != 2:
                continue
            organ_pos = organ.get("pos")
            if not isinstance(organ_pos, dict) or "x" not in organ_pos or "z" not in organ_pos:
                continue

            buff_x, buff_z = self._get_grid_pos(organ_pos)
            self.global_buff_mask[buff_x, buff_z] = 1
            if organ.get("status", 1) == 1:
                self.global_buff_cd[buff_x, buff_z] = 0
                observed_active_points.add((buff_x, buff_z))
            else:
                observed_inactive_points.add((buff_x, buff_z))

        for buff_pos in observed_inactive_points:
            if buff_pos in self.prev_active_buff_points:
                self.global_buff_cd[buff_pos[0], buff_pos[1]] = int(runtime_cfg["buff_cooldown"])

        self.prev_active_buff_points = observed_active_points

    def _compute_frontier_dir_scores(self, hero_pos):
        hero_x, hero_z = self._get_grid_pos(hero_pos)
        lookahead = max(int(Config.FRONTIER_LOOKAHEAD), 1)
        frontier_scores = np.zeros(8, dtype=np.float32)

        for idx, (dir_x, dir_z) in enumerate(FLASH_DIR_XZ):
            dir_x = int(dir_x)
            dir_z = int(dir_z)
            side_x, side_z = -dir_z, dir_x
            total_count = 0.0
            unknown_count = 0.0

            for step in range(1, lookahead + 1):
                base_x = hero_x + dir_x * step
                base_z = hero_z + dir_z * step
                for lateral in (-1, 0, 1):
                    gx = base_x + side_x * lateral
                    gz = base_z + side_z * lateral
                    if 0 <= gx < Config.GLOBAL_MAP_SIZE and 0 <= gz < Config.GLOBAL_MAP_SIZE:
                        total_count += 1.0
                        if self.global_terrain[gx, gz] == -1:
                            unknown_count += 1.0

            frontier_scores[idx] = float(unknown_count / max(total_count, 1.0))

        return frontier_scores

    def _compute_local_recent_revisit_score(self, hero_x_idx, hero_z_idx):
        revisit_values = []
        radius = max(int(Config.LOCAL_REVISIT_RADIUS), 0)
        for dx in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                gx = hero_x_idx + dx
                gz = hero_z_idx + dz
                if not (0 <= gx < Config.GLOBAL_MAP_SIZE and 0 <= gz < Config.GLOBAL_MAP_SIZE):
                    continue
                last_visit_step = int(self.global_last_visit[gx, gz])
                if last_visit_step <= NEG_INF_VISIT // 2:
                    revisit_values.append(0.0)
                else:
                    revisit_values.append(
                        math.exp(
                            -(float(self.step_no) - float(last_visit_step))
                            / max(float(Config.TAU_LOCAL_REVISIT), 1.0)
                        )
                    )
        return float(np.mean(revisit_values)) if revisit_values else 0.0

    def _compute_path_efficiency(self, current_pos=None, current_step_dist=None):
        positions = list(self.recent_positions_long)
        step_distances = list(self.recent_step_distances)
        if current_pos is not None:
            positions.append(current_pos)
        if current_step_dist is not None:
            step_distances.append(float(current_step_dist))
        if len(positions) < 2 or len(step_distances) < 1:
            return 1.0
        k = min(int(Config.PATH_EFF_WINDOW), len(step_distances), len(positions) - 1)
        if k <= 0:
            return 1.0
        current_pos = positions[-1]
        start_pos = positions[-1 - k]
        path_length = float(sum(step_distances[-k:]))
        net_displacement = math.sqrt(
            (float(current_pos[0]) - float(start_pos[0])) ** 2 + (float(current_pos[1]) - float(start_pos[1])) ** 2
        )
        return float(np.clip(net_displacement / (path_length + float(Config.PATH_EFF_EPS)), 0.0, 1.0))

    def _compute_loop_closure_scores(self, current_pos=None):
        positions = list(self.recent_positions_long)
        if current_pos is not None:
            positions.append(current_pos)
        current_pos = positions[-1] if positions else None
        if current_pos is None:
            return 0.0, 0.0

        def _score_for_k(k):
            if len(positions) <= k:
                return 0.0
            anchor_pos = positions[-1 - k]
            dist = math.sqrt(
                (float(current_pos[0]) - float(anchor_pos[0])) ** 2
                + (float(current_pos[1]) - float(anchor_pos[1])) ** 2
            )
            return float(math.exp(-dist / max(float(Config.LOOP_CLOSE_DIST_SCALE), 1e-6)))

        return _score_for_k(int(Config.LOOP_CLOSE_SHORT)), _score_for_k(int(Config.LOOP_CLOSE_MID))

    def _compute_region_loop_score(self, current_pos=None):
        positions = list(self.recent_positions_region)
        if current_pos is not None:
            positions.append(current_pos)
        if len(positions) < 3:
            return 0.0

        path_len = 0.0
        for idx in range(1, len(positions)):
            prev_pos = positions[idx - 1]
            next_pos = positions[idx]
            path_len += math.sqrt(
                (float(next_pos[0]) - float(prev_pos[0])) ** 2 + (float(next_pos[1]) - float(prev_pos[1])) ** 2
            )

        start_pos = positions[0]
        end_pos = positions[-1]
        start_end_dist = math.sqrt(
            (float(end_pos[0]) - float(start_pos[0])) ** 2 + (float(end_pos[1]) - float(start_pos[1])) ** 2
        )
        center_x = float(sum(pos[0] for pos in positions) / len(positions))
        center_z = float(sum(pos[1] for pos in positions) / len(positions))
        max_radius = 0.0
        for pos in positions:
            radius = math.sqrt((float(pos[0]) - center_x) ** 2 + (float(pos[1]) - center_z) ** 2)
            max_radius = max(max_radius, radius)

        closed_term = math.exp(-start_end_dist / max(float(Config.REGION_LOOP_CLOSE_SCALE), 1e-6))
        compact_term = math.exp(
            -max(max_radius - float(Config.REGION_LOOP_VIS_RADIUS), 0.0)
            / max(float(Config.REGION_LOOP_RADIUS_SCALE), 1e-6)
        )
        travel_term = float(
            np.clip(
                (path_len - float(Config.REGION_LOOP_MIN_PATH))
                / max(float(Config.REGION_LOOP_PATH_REF) - float(Config.REGION_LOOP_MIN_PATH), 1e-6),
                0.0,
                1.0,
            )
        )
        return float(closed_term * compact_term * travel_term)

    def _normalize_vec(self, vec):
        vec = np.asarray(vec, dtype=np.float32)
        norm = float(np.linalg.norm(vec))
        if norm <= 1e-6:
            return np.zeros(2, dtype=np.float32)
        return vec / norm

    def _extract_organ_pos(self, organ, hero_pos):
        organ_pos = organ.get("pos")
        if isinstance(organ_pos, dict) and "x" in organ_pos and "z" in organ_pos:
            return {"x": float(organ_pos["x"]), "z": float(organ_pos["z"])}, True
        estimate = self._estimate_entity_pos_from_relative(
            hero_pos, organ.get("hero_relative_direction", 0), organ.get("hero_l2_distance", 5)
        )
        return {"x": float(estimate["x"]), "z": float(estimate["z"])}, False

    def _get_local_center(self, map_info):
        if map_info is None or len(map_info) == 0 or len(map_info[0]) == 0:
            return None
        return len(map_info) // 2, len(map_info[0]) // 2

    def _world_pos_to_local_cell(self, hero_pos, target_pos, map_info):
        center = self._get_local_center(map_info)
        if center is None or target_pos is None:
            return None
        dx = int(round(float(target_pos["x"]) - float(hero_pos["x"])))
        dz = int(round(float(target_pos["z"]) - float(hero_pos["z"])))
        row = center[0] - dz
        col = center[1] + dx
        if 0 <= row < len(map_info) and 0 <= col < len(map_info[0]):
            return row, col
        return None

    def _local_cell_to_world_pos(self, hero_pos, row, col, map_info):
        center = self._get_local_center(map_info)
        if center is None:
            return {"x": float(hero_pos["x"]), "z": float(hero_pos["z"])}
        return {
            "x": float(hero_pos["x"]) + float(col - center[1]),
            "z": float(hero_pos["z"]) - float(row - center[0]),
        }

    def _is_diag_move_valid(self, map_info, row, col, next_row, next_col):
        dr = next_row - row
        dc = next_col - col
        if abs(dr) != 1 or abs(dc) != 1:
            return True
        return self._is_passable(map_info, row + dr, col) or self._is_passable(map_info, row, col + dc)

    def _bfs_local_path_distance(self, map_info, start_cell, target_cell):
        if (
            map_info is None
            or start_cell is None
            or target_cell is None
            or not self._is_passable(map_info, start_cell[0], start_cell[1])
            or not self._is_passable(map_info, target_cell[0], target_cell[1])
        ):
            return False, None

        queue = deque([(start_cell[0], start_cell[1], 0)])
        visited = {start_cell}
        while queue:
            row, col, dist = queue.popleft()
            if dist > Config.RESOURCE_LOCAL_BFS_MAX_DIST:
                continue
            if (row, col) == target_cell:
                return True, dist
            for dr, dc in FLASH_DIR_RC:
                next_row, next_col = row + dr, col + dc
                next_cell = (next_row, next_col)
                if next_cell in visited:
                    continue
                if not self._is_passable(map_info, next_row, next_col):
                    continue
                if not self._is_diag_move_valid(map_info, row, col, next_row, next_col):
                    continue
                visited.add(next_cell)
                queue.append((next_row, next_col, dist + 1))
        return False, None

    def _bfs_local_distance_map(self, map_info, start_cell, max_dist):
        if (
            map_info is None
            or start_cell is None
            or not self._is_passable(map_info, start_cell[0], start_cell[1])
        ):
            return {}

        distance_map = {start_cell: 0.0}
        queue = deque([(start_cell[0], start_cell[1], 0.0)])
        max_dist = float(max(max_dist, 0.0))
        while queue:
            row, col, dist = queue.popleft()
            if dist >= max_dist:
                continue
            for dr, dc in FLASH_DIR_RC:
                next_row, next_col = row + dr, col + dc
                next_cell = (next_row, next_col)
                if next_cell in distance_map:
                    continue
                if not self._is_passable(map_info, next_row, next_col):
                    continue
                if not self._is_diag_move_valid(map_info, row, col, next_row, next_col):
                    continue
                next_dist = dist + 1.0
                if next_dist > max_dist:
                    continue
                distance_map[next_cell] = next_dist
                queue.append((next_row, next_col, next_dist))
        return distance_map

    def _compute_cell_open_score(self, map_info, center_cell):
        if map_info is None or center_cell is None:
            return 0.0
        center_row, center_col = center_cell
        ray_values = np.zeros(8, dtype=np.float32)
        for idx, (dr, dc) in enumerate(FLASH_DIR_RC):
            row, col, dist = center_row, center_col, 0.0
            for _ in range(10):
                next_row = row + dr
                next_col = col + dc
                if not self._is_passable(map_info, next_row, next_col):
                    break
                if not self._is_diag_move_valid(map_info, row, col, next_row, next_col):
                    break
                row, col = next_row, next_col
                dist += 1.0
            ray_values[idx] = float(dist / 10.0)
        return float(np.mean(ray_values))

    def _compute_local_monster_reach_distance(self, map_info, hero_pos, monster_pos, map_anchor_pos=None):
        if map_info is None or hero_pos is None or monster_pos is None:
            return None
        anchor_pos = map_anchor_pos if map_anchor_pos is not None else hero_pos
        hero_cell = self._world_pos_to_local_cell(anchor_pos, hero_pos, map_info)
        monster_cell = self._world_pos_to_local_cell(anchor_pos, monster_pos, map_info)
        if hero_cell is None or monster_cell is None:
            return None
        reachable, path_len = self._bfs_local_path_distance(map_info, monster_cell, hero_cell)
        if not reachable or path_len is None:
            return float(Config.LOCAL_UNREACHABLE_DIST_CAP)
        return float(path_len)

    def _compute_min_monster_reach_metrics(self, map_info, hero_pos, monsters, map_anchor_pos=None):
        anchor_pos = map_anchor_pos if map_anchor_pos is not None else hero_pos
        visible_reach_dists = []
        visible_reach_times = []
        all_reach_dists = []
        all_reach_times = []
        visible_monster_reach_list = []

        for monster in monsters or []:
            if not isinstance(monster, dict):
                continue

            monster_speed = max(float(monster.get("speed", 1.0)), 1.0)
            raw_dist = float(Config.LOCAL_UNREACHABLE_DIST_CAP)
            is_local_visible = False
            monster_pos = monster.get("pos")
            if isinstance(monster_pos, dict) and "x" in monster_pos and "z" in monster_pos:
                reach_dist = self._compute_local_monster_reach_distance(
                    map_info=map_info,
                    hero_pos=hero_pos,
                    monster_pos=monster_pos,
                    map_anchor_pos=anchor_pos,
                )
                if reach_dist is not None:
                    raw_dist = float(reach_dist)
                    is_local_visible = True
                else:
                    raw_dist = self._distance_pos(hero_pos, monster_pos)
            else:
                bucket = monster.get("hero_l2_distance", 5)
                raw_dist = self._estimate_bucket_distance(bucket)

            reach_time = float(
                np.clip(
                    raw_dist / max(monster_speed, 1.0),
                    0.0,
                    float(Config.LOCAL_UNREACHABLE_TIME_CAP),
                )
            )
            reach_dist_capped = float(np.clip(raw_dist, 0.0, float(Config.LOCAL_UNREACHABLE_DIST_CAP)))

            all_reach_dists.append(reach_dist_capped)
            all_reach_times.append(reach_time)
            if is_local_visible:
                visible_reach_dists.append(reach_dist_capped)
                visible_reach_times.append(reach_time)
                visible_monster_reach_list.append(
                    {
                        "reach_dist": reach_dist_capped,
                        "reach_time": reach_time,
                        "speed": monster_speed,
                    }
                )

        default_dist = float(Config.LOCAL_UNREACHABLE_DIST_CAP)
        default_time = float(Config.LOCAL_UNREACHABLE_TIME_CAP)
        return {
            "min_reach_dist_visible": min(visible_reach_dists) if visible_reach_dists else default_dist,
            "min_reach_time_visible": min(visible_reach_times) if visible_reach_times else default_time,
            "min_reach_dist_all": min(all_reach_dists) if all_reach_dists else default_dist,
            "min_reach_time_all": min(all_reach_times) if all_reach_times else default_time,
            "visible_monster_reach_list": visible_monster_reach_list,
        }

    def _monster_time_threat(self, reach_time):
        reach_time = float(np.clip(reach_time, 0.0, float(Config.LOCAL_UNREACHABLE_TIME_CAP)))
        base = 1.0 / (
            1.0
            + (reach_time / max(float(Config.MONSTER_TIME_THREAT_TAU), 1e-6)) ** float(Config.MONSTER_TIME_THREAT_ALPHA)
        )
        crit = float(Config.MONSTER_CRITICAL_BONUS) if reach_time <= float(Config.MONSTER_CRITICAL_TIME_THR) else 0.0
        return float(np.clip(base + crit, 0.0, 1.0))

    def _compute_pressure_scores_v2(
        self,
        min_reach_time_visible,
        min_reach_time_all,
        monsters,
        time_to_monster2_ratio,
        time_to_monster_speedup_ratio,
        local_open_score,
        is_flash_avail,
        has_buff,
        runtime_cfg,
    ):
        visible_monster_threat = self._monster_time_threat(min_reach_time_visible)
        all_monster_threat = self._monster_time_threat(min_reach_time_all)
        monster_count_term = 0.0 if sum(1 for monster in monsters if isinstance(monster, dict)) <= 1 else 1.0
        monster_threat = float(np.clip(max(visible_monster_threat, all_monster_threat) + 0.08 * monster_count_term, 0.0, 1.0))

        remaining_to_monster2 = float(time_to_monster2_ratio) * max(float(runtime_cfg["monster_interval"]), 1.0)
        remaining_to_speedup = float(time_to_monster_speedup_ratio) * max(float(runtime_cfg["monster_speedup"]), 1.0)
        phase_monster2_term = float(
            np.clip(1.0 - remaining_to_monster2 / Config.PRESSURE_MONSTER2_WARN_WINDOW, 0.0, 1.0)
        )
        phase_speedup_term = float(
            np.clip(1.0 - remaining_to_speedup / Config.PRESSURE_SPEEDUP_WARN_WINDOW, 0.0, 1.0)
        )
        phase_term = float(0.55 * phase_monster2_term + 0.45 * phase_speedup_term)
        trap_term = float(np.clip(1.0 - float(local_open_score), 0.0, 1.0))
        monster_trap_term = float(monster_threat * trap_term)

        env_threat_score = float(
            np.clip(
                Config.ENV_THREAT_W_MONSTER * monster_threat
                + Config.ENV_THREAT_W_PHASE * phase_term
                + Config.ENV_THREAT_W_TRAP * trap_term
                + Config.ENV_THREAT_W_MONSTER_TRAP * monster_trap_term,
                0.0,
                1.0,
            )
        )
        flash_relief = float(Config.FLASH_PRESSURE_RELIEF_HAS_BUFF * float(has_buff))
        flash_decision_pressure = float(
            np.clip(
                env_threat_score - Config.FLASH_PRESSURE_RELIEF_ALPHA * flash_relief,
                0.0,
                1.0,
            )
        )
        greed_relief = float(
            Config.GREED_PRESSURE_RELIEF_HAS_BUFF * float(has_buff)
            + Config.GREED_PRESSURE_RELIEF_FLASH_READY * float(is_flash_avail)
        )
        greed_pressure_score = float(
            np.clip(
                env_threat_score - Config.GREED_PRESSURE_RELIEF_ALPHA * greed_relief,
                0.0,
                1.0,
            )
        )
        return env_threat_score, flash_decision_pressure, greed_pressure_score

    def _compute_best_walk_pressure_after(
        self,
        map_info,
        hero_pos,
        monsters,
        legal_action,
        time_to_monster2_ratio,
        time_to_monster_speedup_ratio,
        is_flash_avail,
        has_buff,
        runtime_cfg,
    ):
        current_metrics = self._compute_min_monster_reach_metrics(map_info, hero_pos, monsters)
        current_center = self._get_local_center(map_info)
        current_open_score = self._compute_cell_open_score(map_info, current_center) if current_center is not None else 0.0
        _, current_flash_pressure, _ = self._compute_pressure_scores_v2(
            min_reach_time_visible=current_metrics["min_reach_time_visible"],
            min_reach_time_all=current_metrics["min_reach_time_all"],
            monsters=monsters,
            time_to_monster2_ratio=time_to_monster2_ratio,
            time_to_monster_speedup_ratio=time_to_monster_speedup_ratio,
            local_open_score=current_open_score,
            is_flash_avail=is_flash_avail,
            has_buff=has_buff,
            runtime_cfg=runtime_cfg,
        )
        best_pressure_after = float(current_flash_pressure)
        best_idx = -1
        best_reach_time_after = float(current_metrics["min_reach_time_visible"])

        if map_info is None or current_center is None:
            return best_pressure_after, best_idx, best_reach_time_after

        for idx, (dr, dc) in enumerate(FLASH_DIR_RC):
            if idx >= 8:
                break
            if legal_action is not None and (len(legal_action) <= idx or float(legal_action[idx]) <= 0.0):
                continue
            next_row = current_center[0] + dr
            next_col = current_center[1] + dc
            if not self._is_passable(map_info, next_row, next_col):
                continue
            if not self._is_diag_move_valid(map_info, current_center[0], current_center[1], next_row, next_col):
                continue

            next_pos = self._local_cell_to_world_pos(hero_pos, next_row, next_col, map_info)
            reach_metrics = self._compute_min_monster_reach_metrics(
                map_info=map_info,
                hero_pos=next_pos,
                monsters=monsters,
                map_anchor_pos=hero_pos,
            )
            next_open_score = self._compute_cell_open_score(map_info, (next_row, next_col))
            _, next_flash_pressure, _ = self._compute_pressure_scores_v2(
                min_reach_time_visible=reach_metrics["min_reach_time_visible"],
                min_reach_time_all=reach_metrics["min_reach_time_all"],
                monsters=monsters,
                time_to_monster2_ratio=time_to_monster2_ratio,
                time_to_monster_speedup_ratio=time_to_monster_speedup_ratio,
                local_open_score=next_open_score,
                is_flash_avail=is_flash_avail,
                has_buff=has_buff,
                runtime_cfg=runtime_cfg,
            )
            if best_idx < 0 or next_flash_pressure < best_pressure_after:
                best_pressure_after = float(next_flash_pressure)
                best_idx = idx
                best_reach_time_after = float(reach_metrics["min_reach_time_visible"])

        return best_pressure_after, best_idx, best_reach_time_after

    def _compute_flash_resource_relief(self, selected_idx, actual_resource_gain, target_resource):
        if not (0 <= selected_idx < 8):
            return 0.0
        proxy_gain = max(
            float(actual_resource_gain),
            float(self.prev_flash_dir_path_resource_gain[selected_idx]) if len(self.prev_flash_dir_path_resource_gain) > selected_idx else 0.0,
        )
        if proxy_gain < float(Config.FLASH_RESOURCE_RELIEF_THR):
            return 0.0
        if (
            target_resource is not None
            and bool(target_resource["walk_reachable_flag"])
            and float(target_resource["walk_path_len_norm"]) <= 0.35
        ):
            return 0.0
        relief = float(
            np.clip(
                Config.LAMBDA_FLASH_RESOURCE_RELIEF * proxy_gain,
                0.0,
                float(Config.FLASH_RESOURCE_RELIEF_MAX),
            )
        )
        return relief

    def _compute_line_blocked_flag(self, map_info, start_cell, target_cell):
        if map_info is None or start_cell is None or target_cell is None:
            return 0.0
        row0, col0 = start_cell
        row1, col1 = target_cell
        dr = row1 - row0
        dc = col1 - col0
        steps = max(abs(dr), abs(dc))
        if steps <= 1:
            return 0.0
        for step in range(1, steps):
            t = float(step) / float(steps)
            row = int(round(row0 + dr * t))
            col = int(round(col0 + dc * t))
            if not self._is_passable(map_info, row, col):
                return 1.0
        return 0.0

    def _compute_flash_reachability_to_target(self, map_info, hero_pos, target_pos, flash_direction_info):
        result = {
            "flash_reachable": False,
            "best_flash_idx": -1,
            "best_flash_score": 0.0,
            "best_flash_post_dist": float("inf"),
        }
        if target_pos is None:
            return result

        target_vec = self._normalize_vec(
            np.array([float(target_pos["x"] - hero_pos["x"]), float(target_pos["z"] - hero_pos["z"])], dtype=np.float32)
        )
        if float(np.linalg.norm(target_vec)) <= 1e-6:
            result["flash_reachable"] = True
            result["best_flash_score"] = 1.0
            result["best_flash_post_dist"] = 0.0
            return result

        center = self._get_local_center(map_info)
        target_local_cell = self._world_pos_to_local_cell(hero_pos, target_pos, map_info) if map_info is not None else None

        for idx, flash_dir_vec in enumerate(MOVE_DIR_UNIT):
            align = float(np.dot(flash_dir_vec, target_vec))
            reachable_ratio = float(flash_direction_info["reachable_ratio"][idx])
            if align < Config.RESOURCE_FLASH_ALIGN_THR or reachable_ratio < Config.RESOURCE_FLASH_REACHABLE_RATIO_THR:
                continue

            actual_range = float(flash_direction_info["actual_range"][idx])
            landing_cell = None
            if center is not None:
                landing_cell = (
                    center[0] + int(FLASH_DIR_RC[idx][0] * actual_range),
                    center[1] + int(FLASH_DIR_RC[idx][1] * actual_range),
                )
            landing_pos = {
                "x": float(hero_pos["x"]) + float(FLASH_DIR_XZ[idx][0]) * actual_range,
                "z": float(hero_pos["z"]) + float(FLASH_DIR_XZ[idx][1]) * actual_range,
            }
            if landing_cell is not None and target_local_cell is not None:
                post_reachable, post_path_len = self._bfs_local_path_distance(map_info, landing_cell, target_local_cell)
                post_dist = float(post_path_len) if post_reachable and post_path_len is not None else float(Config.LOCAL_UNREACHABLE_DIST_CAP)
            else:
                post_dist = self._distance_pos(landing_pos, target_pos)
            path_dist = self._point_to_segment_distance(target_pos, hero_pos, landing_pos)
            near_target = min(post_dist, path_dist) <= Config.RESOURCE_FLASH_TARGET_NEAR_DIST
            if not near_target:
                continue

            score = float(
                np.clip(
                    0.45 * align
                    + 0.35 * reachable_ratio
                    + 0.20 * (1.0 - np.clip(post_dist / Config.FLASH_TARGET_POST_REACH_DEN, 0.0, 1.0)),
                    0.0,
                    1.0,
                )
            )
            if score > result["best_flash_score"]:
                result = {
                    "flash_reachable": True,
                    "best_flash_idx": idx,
                    "best_flash_score": score,
                    "best_flash_post_dist": float(post_dist),
                }
        return result

    def _overlay_current_fov_on_terrain(self, hero_pos, map_info, base_terrain):
        if (
            base_terrain is None
            or map_info is None
            or len(map_info) == 0
            or len(map_info[0]) == 0
        ):
            return base_terrain
        terrain = np.array(base_terrain, copy=True)
        hero_x, hero_z = self._get_grid_pos(hero_pos)
        center = self._get_local_center(map_info)
        for row in range(len(map_info)):
            for col in range(len(map_info[0])):
                gx = hero_x + (col - center[1])
                gz = hero_z - (row - center[0])
                if 0 <= gx < Config.GLOBAL_MAP_SIZE and 0 <= gz < Config.GLOBAL_MAP_SIZE:
                    terrain[gx, gz] = 0 if map_info[row][col] == 0 else 1
        return terrain

    def _is_passable_on_terrain(self, terrain, gx, gz):
        return (
            terrain is not None
            and 0 <= gx < Config.GLOBAL_MAP_SIZE
            and 0 <= gz < Config.GLOBAL_MAP_SIZE
            and terrain[gx, gz] == 1
        )

    def _is_diag_move_valid_on_terrain(self, terrain, gx, gz, next_gx, next_gz):
        dx = next_gx - gx
        dz = next_gz - gz
        if abs(dx) != 1 or abs(dz) != 1:
            return True
        return self._is_passable_on_terrain(terrain, gx + dx, gz) or self._is_passable_on_terrain(terrain, gx, gz + dz)

    def _bfs_known_reachable(self, terrain, start_x, start_z):
        if not self._is_passable_on_terrain(terrain, start_x, start_z):
            return set()
        queue = deque([(start_x, start_z)])
        visited = {(start_x, start_z)}
        while queue:
            gx, gz = queue.popleft()
            for dx, dz in FLASH_DIR_XZ:
                next_gx = gx + int(dx)
                next_gz = gz + int(dz)
                next_cell = (next_gx, next_gz)
                if next_cell in visited:
                    continue
                if not self._is_passable_on_terrain(terrain, next_gx, next_gz):
                    continue
                if not self._is_diag_move_valid_on_terrain(terrain, gx, gz, next_gx, next_gz):
                    continue
                visited.add(next_cell)
                queue.append(next_cell)
        return visited

    def _compute_reachable_frontier_density(self, terrain, hero_x, hero_z):
        if terrain is None:
            return 0.0
        reachable_set = self._bfs_known_reachable(terrain, hero_x, hero_z)
        if not reachable_set:
            return 0.0

        center_x = hero_x
        center_z = hero_z
        radius = Config.VIEW_RADIUS
        reachable_visible_passable_count = 0.0
        frontier_passable_count = 0.0
        neighbor_radius = max(int(Config.EXPLORE_FRONTIER_NEIGHBOR_RADIUS), 1)

        for dz in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                gx = center_x + dx
                gz = center_z + dz
                if not (0 <= gx < Config.GLOBAL_MAP_SIZE and 0 <= gz < Config.GLOBAL_MAP_SIZE):
                    continue
                if (gx, gz) not in reachable_set or terrain[gx, gz] != 1:
                    continue
                reachable_visible_passable_count += 1.0
                has_unknown_neighbor = False
                for ndz in range(-neighbor_radius, neighbor_radius + 1):
                    for ndx in range(-neighbor_radius, neighbor_radius + 1):
                        if ndx == 0 and ndz == 0:
                            continue
                        ngx = gx + ndx
                        ngz = gz + ndz
                        if not (0 <= ngx < Config.GLOBAL_MAP_SIZE and 0 <= ngz < Config.GLOBAL_MAP_SIZE):
                            continue
                        if terrain[ngx, ngz] == -1:
                            has_unknown_neighbor = True
                            break
                    if has_unknown_neighbor:
                        break
                if has_unknown_neighbor:
                    frontier_passable_count += 1.0

        return float(frontier_passable_count / max(reachable_visible_passable_count, 1.0))

    def _compute_new_reachable_road_metrics(self, hero_pos, map_info):
        if map_info is None or len(map_info) == 0 or len(map_info[0]) == 0:
            return {
                "new_reachable_road_count": 0.0,
                "new_reachable_road_ratio": 0.0,
                "reachable_frontier_density": 0.0,
                "valid_visible_count": 0.0,
            }

        old_terrain = np.array(self.global_terrain, copy=True)
        new_terrain = self._overlay_current_fov_on_terrain(hero_pos, map_info, old_terrain)
        hero_x, hero_z = self._get_grid_pos(hero_pos)
        center = self._get_local_center(map_info)
        reachable_set = self._bfs_known_reachable(new_terrain, hero_x, hero_z)

        new_reachable_road_count = 0.0
        valid_visible_count = 0.0
        for row in range(len(map_info)):
            for col in range(len(map_info[0])):
                gx = hero_x + (col - center[1])
                gz = hero_z - (row - center[0])
                if not (0 <= gx < Config.GLOBAL_MAP_SIZE and 0 <= gz < Config.GLOBAL_MAP_SIZE):
                    continue
                valid_visible_count += 1.0
                if old_terrain[gx, gz] == -1 and new_terrain[gx, gz] == 1 and (gx, gz) in reachable_set:
                    new_reachable_road_count += 1.0

        return {
            "new_reachable_road_count": float(new_reachable_road_count),
            "new_reachable_road_ratio": float(new_reachable_road_count / max(valid_visible_count, 1.0)),
            "reachable_frontier_density": self._compute_reachable_frontier_density(new_terrain, hero_x, hero_z),
            "valid_visible_count": float(valid_visible_count),
        }

    def _compute_explore_direction_gains(self, hero_pos, map_info):
        explore_dir_gain = np.zeros(8, dtype=np.float32)
        if map_info is None or len(map_info) == 0 or len(map_info[0]) == 0:
            return explore_dir_gain, 0.0, 0.0, 0.0

        old_terrain = np.array(self.global_terrain, copy=True)
        overlay_terrain = self._overlay_current_fov_on_terrain(hero_pos, map_info, old_terrain)
        hero_x, hero_z = self._get_grid_pos(hero_pos)
        center = self._get_local_center(map_info)
        radius = Config.VIEW_RADIUS
        step_scale = max(int(Config.EXPLORE_PREDICT_STEP), 1)
        log_alpha = float(max(Config.EXPLORE_DIR_GAIN_LOG_ALPHA, 1e-6))

        for idx, (dir_x, dir_z) in enumerate(FLASH_DIR_XZ):
            current_row, current_col = center
            predicted_x, predicted_z = hero_x, hero_z
            can_move = True
            for _ in range(step_scale):
                next_row = current_row - int(dir_z)
                next_col = current_col + int(dir_x)
                if not self._is_passable(map_info, next_row, next_col):
                    can_move = False
                    break
                if not self._is_diag_move_valid(map_info, current_row, current_col, next_row, next_col):
                    can_move = False
                    break
                current_row, current_col = next_row, next_col
                predicted_x += int(dir_x)
                predicted_z += int(dir_z)

            if not can_move or not (0 <= predicted_x < Config.GLOBAL_MAP_SIZE and 0 <= predicted_z < Config.GLOBAL_MAP_SIZE):
                continue

            reachable_set = self._bfs_known_reachable(overlay_terrain, predicted_x, predicted_z)
            predicted_new_reachable_count = 0.0
            predicted_valid_visible_count = 0.0
            for dz in range(-radius, radius + 1):
                for dx in range(-radius, radius + 1):
                    gx = predicted_x + dx
                    gz = predicted_z + dz
                    if not (0 <= gx < Config.GLOBAL_MAP_SIZE and 0 <= gz < Config.GLOBAL_MAP_SIZE):
                        continue
                    predicted_valid_visible_count += 1.0
                    if old_terrain[gx, gz] == -1 and overlay_terrain[gx, gz] == 1 and (gx, gz) in reachable_set:
                        predicted_new_reachable_count += 1.0

            raw_dir_gain = float(predicted_new_reachable_count / max(predicted_valid_visible_count, 1.0))
            explore_dir_gain[idx] = float(math.log1p(log_alpha * raw_dir_gain) / math.log1p(log_alpha))

        sorted_gain = np.sort(explore_dir_gain)
        best_explore_dir_gain = float(sorted_gain[-1]) if len(sorted_gain) > 0 else 0.0
        second_explore_dir_gain = float(sorted_gain[-2]) if len(sorted_gain) > 1 else best_explore_dir_gain
        reachable_frontier_density = self._compute_reachable_frontier_density(overlay_terrain, hero_x, hero_z)
        return explore_dir_gain, best_explore_dir_gain, second_explore_dir_gain, reachable_frontier_density

    def _has_clear_reachable_target_resource(self, target_resource):
        if target_resource is None:
            return False
        return bool(target_resource["walk_reachable_flag"]) and (
            float(target_resource["walk_path_len_norm"]) <= Config.EXPLORE_CLEAR_TARGET_PATH_THR
        ) and (
            float(target_resource["line_blocked_flag"]) <= Config.EXPLORE_CLEAR_TARGET_LINE_BLOCK_MAX
        )

    def _compute_explore_gate(self, effective_pressure_score, target_resource):
        pressure_gate = float(np.clip(1.0 - float(effective_pressure_score) ** Config.EXPLORE_GATE_GAMMA, 0.0, 1.0))
        resource_gate = Config.EXPLORE_RESOURCE_SUPPRESS_FACTOR if self._has_clear_reachable_target_resource(target_resource) else 1.0
        return float(pressure_gate * resource_gate)

    def _compute_dual_pressure_scores(
        self,
        cur_min_dist_raw_visible,
        cur_min_dist_raw_all,
        monsters,
        time_to_monster2_ratio,
        time_to_monster_speedup_ratio,
        local_open_score,
        is_flash_avail,
        has_buff,
        runtime_cfg,
    ):
        # 兼容保留旧接口名，语义已迁移到 reach-time 驱动的 pressure v2。
        fallback_visible_time = float(
            np.clip(
                float(cur_min_dist_raw_visible) / max(MAX_MONSTER_SPEED, 1.0),
                0.0,
                float(Config.LOCAL_UNREACHABLE_TIME_CAP),
            )
        )
        fallback_all_time = float(
            np.clip(
                float(cur_min_dist_raw_all) / max(MAX_MONSTER_SPEED, 1.0),
                0.0,
                float(Config.LOCAL_UNREACHABLE_TIME_CAP),
            )
        )
        env_threat_score, _, greed_pressure_score = self._compute_pressure_scores_v2(
            min_reach_time_visible=fallback_visible_time,
            min_reach_time_all=fallback_all_time,
            monsters=monsters,
            time_to_monster2_ratio=time_to_monster2_ratio,
            time_to_monster_speedup_ratio=time_to_monster_speedup_ratio,
            local_open_score=local_open_score,
            is_flash_avail=is_flash_avail,
            has_buff=has_buff,
            runtime_cfg=runtime_cfg,
        )
        return env_threat_score, greed_pressure_score

    def _build_resource_candidate(self, organ, hero_pos, map_info, flash_direction_info):
        pos, has_abs_pos = self._extract_organ_pos(organ, hero_pos)
        dx = float(pos["x"] - hero_pos["x"])
        dz = float(pos["z"] - hero_pos["z"])
        raw_dist = math.sqrt(dx**2 + dz**2)
        sub_type = int(organ.get("sub_type", 0))
        base = Config.RESOURCE_VALUE_TREASURE_BASE if sub_type == 1 else Config.RESOURCE_VALUE_BUFF_BASE
        bonus = Config.RESOURCE_VALUE_BUFF_BONUS if sub_type == 2 else 0.0
        bucket = self._safe_int(organ.get("hero_l2_distance", 5), 5)
        direction = self._safe_int(organ.get("hero_relative_direction", 0), 0)
        dx_norm = float(np.clip(dx / 40.0, -1.0, 1.0))
        dz_norm = float(np.clip(dz / 40.0, -1.0, 1.0))
        dir_vec = self._normalize_vec(np.array([dx_norm, dz_norm], dtype=np.float32))

        center = self._get_local_center(map_info)
        start_cell = center
        local_cell = self._world_pos_to_local_cell(hero_pos, pos, map_info) if has_abs_pos else None
        walk_reachable_flag = False
        walk_path_len = None
        walk_path_len_norm = 1.0
        line_blocked_flag = 0.0
        if local_cell is not None and start_cell is not None:
            walk_reachable_flag, walk_path_len = self._bfs_local_path_distance(map_info, start_cell, local_cell)
            if walk_reachable_flag and walk_path_len is not None:
                walk_path_len_norm = float(
                    np.clip(float(walk_path_len) / max(float(Config.TREASURE_REACH_DIST_NORM_DEN), 1.0), 0.0, 1.0)
                )
            else:
                walk_path_len_norm = 1.0
            line_blocked_flag = self._compute_line_blocked_flag(map_info, start_cell, local_cell)

        flash_reach = self._compute_flash_reachability_to_target(map_info, hero_pos, pos, flash_direction_info)
        flash_reachable_flag = bool(flash_reach["flash_reachable"])
        flash_best_score = float(flash_reach["best_flash_score"])
        flash_post_dist_norm = float(
            np.clip(float(flash_reach["best_flash_post_dist"]) / Config.FLASH_TARGET_POST_REACH_DEN, 0.0, 1.0)
        ) if flash_reachable_flag else 1.0

        if walk_reachable_flag:
            effective_dist_norm = walk_path_len_norm
        elif flash_reachable_flag:
            effective_dist_norm = float(np.clip(flash_post_dist_norm + 0.25, 0.0, 1.0))
        else:
            effective_dist_norm = float(
                np.clip(raw_dist / Config.RESOURCE_TARGET_DIST_NORM_DEN + Config.RESOURCE_UNREACHABLE_PENALTY, 0.0, 1.0)
            )

        value_score = float(
            base
            + bonus
            + Config.RESOURCE_WALK_REACHABLE_BONUS * float(walk_reachable_flag)
            + Config.RESOURCE_FLASH_REACHABLE_BONUS * float((not walk_reachable_flag) and flash_reachable_flag)
            - Config.RESOURCE_WALK_PATH_COST * float(walk_path_len_norm)
            - Config.RESOURCE_LINE_BLOCKED_PENALTY * float(line_blocked_flag)
            - Config.RESOURCE_FLASH_PATH_COST * float((not walk_reachable_flag) * flash_post_dist_norm)
        )

        return {
            "sub_type": sub_type,
            "pos": pos,
            "direction": direction,
            "bucket": bucket,
            "dx_norm": dx_norm,
            "dz_norm": dz_norm,
            "dist_norm": effective_dist_norm,
            "value_score": value_score,
            "dir_vec": dir_vec,
            "is_visible": bool(has_abs_pos),
            "local_cell": local_cell,
            "walk_reachable_flag": bool(walk_reachable_flag),
            "walk_path_len": walk_path_len,
            "walk_path_len_norm": float(walk_path_len_norm),
            "line_blocked_flag": float(line_blocked_flag),
            "flash_reachable_flag": bool(flash_reachable_flag),
            "flash_best_score": float(flash_best_score),
        }

    def _candidate_priority(self, candidate):
        if candidate["walk_reachable_flag"]:
            tier = 0
            path_key = candidate["walk_path_len_norm"]
        elif candidate["flash_reachable_flag"]:
            tier = 1
            path_key = 1.0 - 0.25 * candidate["flash_best_score"]
        else:
            tier = 2
            path_key = candidate["dist_norm"] + Config.RESOURCE_UNREACHABLE_PENALTY
        buff_bias = -0.05 if candidate["sub_type"] == 2 else 0.0
        return (
            tier,
            float(path_key) + buff_bias,
            -float(candidate["value_score"]),
            float(candidate["line_blocked_flag"]),
            float(candidate["dist_norm"]),
        )

    def _is_candidate_better(self, candidate, best_candidate):
        if best_candidate is None:
            return True
        return self._candidate_priority(candidate) < self._candidate_priority(best_candidate)

    def _select_visible_target_resource(
        self,
        organs,
        hero_pos,
        map_info,
        flash_direction_info,
        effective_pressure_score,
        allowed_sub_types=None,
    ):
        del effective_pressure_score
        allowed = {1, 2} if allowed_sub_types is None else set(allowed_sub_types)
        best_candidate = None
        for organ in organs or []:
            if organ.get("status", 1) != 1:
                continue
            if organ.get("sub_type") not in allowed:
                continue
            candidate = self._build_resource_candidate(organ, hero_pos, map_info, flash_direction_info)
            if self._is_candidate_better(candidate, best_candidate):
                best_candidate = candidate
        return best_candidate

    def _select_visible_target_treasure(
        self,
        organs,
        hero_pos,
        map_info,
        flash_direction_info,
    ):
        return self._select_visible_target_resource(
            organs=organs,
            hero_pos=hero_pos,
            map_info=map_info,
            flash_direction_info=flash_direction_info,
            effective_pressure_score=0.0,
            allowed_sub_types={1},
        )

    def _has_clear_reachable_treasure(self, target_treasure):
        if target_treasure is None:
            return False
        return (
            bool(target_treasure.get("walk_reachable_flag", False))
            and float(target_treasure.get("walk_path_len_norm", 1.0)) <= Config.TREASURE_CLEAR_PATH_THR
            and float(target_treasure.get("line_blocked_flag", 1.0)) <= Config.TREASURE_CLEAR_LINE_BLOCK_MAX
        )

    def _make_treasure_key(self, treasure_candidate):
        if treasure_candidate is None:
            return None
        pos = treasure_candidate.get("pos")
        if bool(treasure_candidate.get("is_visible", False)) and isinstance(pos, dict) and "x" in pos and "z" in pos:
            return self._get_grid_pos(pos)
        direction = int(treasure_candidate.get("direction", 0))
        bucket = int(treasure_candidate.get("bucket", 5))
        return ("est", direction, bucket)

    def _build_treasure_guidance(self, organs, hero_pos, target_treasure):
        if target_treasure is not None:
            return {
                "treasure_guidance_exists": True,
                "treasure_guidance_visible": bool(target_treasure.get("is_visible", False)),
                "treasure_guidance_dx_norm": float(target_treasure.get("dx_norm", 0.0)),
                "treasure_guidance_dz_norm": float(target_treasure.get("dz_norm", 0.0)),
                "treasure_guidance_dist_norm": float(target_treasure.get("dist_norm", 1.0)),
                "treasure_guidance_key": self._make_treasure_key(target_treasure),
            }

        closest = None
        for organ in organs or []:
            if organ.get("status", 1) != 1 or organ.get("sub_type") != 1:
                continue
            pos, has_abs_pos = self._extract_organ_pos(organ, hero_pos)
            if has_abs_pos:
                dist = float(self._distance_pos(hero_pos, pos))
                dist_norm = float(np.clip(dist / 40.0, 0.0, 1.0))
                dx_norm = float(np.clip((pos["x"] - hero_pos["x"]) / 40.0, -1.0, 1.0))
                dz_norm = float(np.clip((pos["z"] - hero_pos["z"]) / 40.0, -1.0, 1.0))
                key = self._get_grid_pos(pos)
                score = (0, dist_norm)
            else:
                direction = self._safe_int(organ.get("hero_relative_direction", 0), 0)
                bucket = self._safe_int(organ.get("hero_l2_distance", 5), 5)
                dir_vec = DIR_MAP.get(direction, (0.0, 0.0))
                dx_norm, dz_norm = float(dir_vec[0]), float(dir_vec[1])
                dist_norm = float(np.clip(bucket / 5.0, 0.0, 1.0))
                key = ("est", direction, bucket)
                score = (1, dist_norm)

            candidate = {
                "treasure_guidance_exists": True,
                "treasure_guidance_visible": bool(has_abs_pos),
                "treasure_guidance_dx_norm": dx_norm,
                "treasure_guidance_dz_norm": dz_norm,
                "treasure_guidance_dist_norm": dist_norm,
                "treasure_guidance_key": key,
                "_score": score,
            }
            if closest is None or candidate["_score"] < closest["_score"]:
                closest = candidate

        if closest is None:
            return {
                "treasure_guidance_exists": False,
                "treasure_guidance_visible": False,
                "treasure_guidance_dx_norm": 0.0,
                "treasure_guidance_dz_norm": 0.0,
                "treasure_guidance_dist_norm": 1.0,
                "treasure_guidance_key": None,
            }
        closest.pop("_score", None)
        return closest

    def _apply_close_treasure_soft_bias(
        self,
        legal_action,
        target_treasure,
        greed_pressure_score,
        local_open_score,
    ):
        refined = np.array(legal_action, dtype=np.float32, copy=True)
        if not Config.ENABLE_CLOSE_TREASURE_SOFT_BIAS:
            return refined
        if target_treasure is None or not bool(target_treasure.get("walk_reachable_flag", False)):
            return refined
        if float(target_treasure.get("walk_path_len_norm", 1.0)) > Config.TREASURE_NEAR_PATH_THR:
            return refined
        if greed_pressure_score > Config.CLOSE_TREASURE_SAFETY_THR:
            return refined
        if local_open_score < Config.CLOSE_TREASURE_OPEN_THR:
            return refined

        target_dir_vec = self._normalize_vec(target_treasure.get("dir_vec", np.zeros(2, dtype=np.float32)))
        if float(np.linalg.norm(target_dir_vec)) <= 1e-6:
            return refined
        move_align = np.matmul(MOVE_DIR_UNIT, target_dir_vec)
        for idx in range(8):
            if refined[idx] <= 0.0:
                continue
            if float(move_align[idx]) >= 0.15:
                refined[idx] = max(refined[idx], float(Config.CLOSE_TREASURE_ACTION_BOOST))
            elif float(move_align[idx]) <= -0.15:
                refined[idx] = min(refined[idx], float(Config.CLOSE_TREASURE_ACTION_SUPPRESS))

        if np.sum(refined[:8] > Config.SOFT_ACTION_EPS) <= 0:
            return np.array(legal_action, dtype=np.float32, copy=True)
        return refined.astype(np.float32)

    def _compute_treasure_rewards(
        self,
        *,
        target_treasure,
        treasure_guidance,
        current_treasures,
        last_treasures_before_update,
        current_buffs,
        last_buffs_before_update,
        env_threat_score,
        greed_pressure_score,
        local_open_score,
    ):
        del current_buffs, last_buffs_before_update
        delta_treasure = max(int(current_treasures) - int(last_treasures_before_update), 0)
        clear_treasure = self._has_clear_reachable_treasure(target_treasure)
        target_key = self._make_treasure_key(target_treasure)
        current_path = (
            float(target_treasure.get("walk_path_len_norm", target_treasure.get("dist_norm", 1.0)))
            if target_treasure is not None
            else 1.0
        )
        same_target = bool(
            target_treasure is not None
            and self.prev_target_treasure_exists
            and target_key == self.prev_target_treasure_key
        )
        prev_path = float(self.prev_target_treasure_path_dist_norm)
        path_progress = max(prev_path - current_path, 0.0) if same_target else 0.0

        guidance_exists = bool(treasure_guidance.get("treasure_guidance_exists", False)) if treasure_guidance else False
        guidance_key = treasure_guidance.get("treasure_guidance_key") if treasure_guidance else None
        cur_guidance_dist = float(treasure_guidance.get("treasure_guidance_dist_norm", 1.0)) if guidance_exists else 1.0
        same_guidance = bool(self.prev_treasure_guidance_exists and guidance_exists and guidance_key == self.prev_treasure_guidance_key)
        prev_guidance_dist = float(self.prev_treasure_guidance_dist_norm)

        pressure_scale_approach = max(
            float(Config.TREASURE_APPROACH_MIN_SCALE),
            float((1.0 - greed_pressure_score) ** Config.TREASURE_REWARD_PRESSURE_POWER),
        )
        pressure_scale_guidance = max(
            float(Config.TREASURE_GUIDANCE_MIN_SCALE),
            float((1.0 - greed_pressure_score) ** Config.TREASURE_REWARD_PRESSURE_POWER),
        )

        r_treasure_collect = float(Config.TREASURE_COLLECT_REWARD * delta_treasure)

        r_treasure_approach = 0.0
        if Config.LAMBDA_TREASURE_APPROACH > 0.0 and clear_treasure and same_target:
            approach_gain = 1.0 - math.exp(-Config.TREASURE_APPROACH_EXP_K * path_progress)
            r_treasure_approach = (
                Config.LAMBDA_TREASURE_APPROACH
                * pressure_scale_approach
                * float(approach_gain)
            )

        r_treasure_guidance = 0.0
        guidance_progress = 0.0
        if Config.LAMBDA_TREASURE_GUIDANCE > 0.0 and (not clear_treasure) and guidance_exists and same_guidance:
            delta_guidance = prev_guidance_dist - cur_guidance_dist
            guide_gain = float(
                np.clip(
                    np.sign(delta_guidance) * (1.0 - math.exp(-Config.TREASURE_GUIDANCE_EXP_K * abs(delta_guidance))),
                    -Config.TREASURE_GUIDANCE_CLIP,
                    Config.TREASURE_GUIDANCE_CLIP,
                )
            )
            guidance_progress = max(delta_guidance, 0.0)
            r_treasure_guidance = (
                Config.LAMBDA_TREASURE_GUIDANCE
                * pressure_scale_guidance
                * guide_gain
            )

        toward_treasure_flag = (r_treasure_approach > 0.0) or (r_treasure_guidance > 0.0)
        threat_rise = max(float(env_threat_score) - float(self.prev_raw_threat_score), 0.0)
        r_treasure_conflict_penalty = 0.0
        if Config.LAMBDA_TREASURE_CONFLICT > 0.0:
            r_treasure_conflict_penalty = (
                -Config.LAMBDA_TREASURE_CONFLICT
                * float(toward_treasure_flag)
                * float(self.prev_raw_threat_score <= Config.TREASURE_CONFLICT_PRESSURE_THR)
                * threat_rise
            )

        backtrack_amount = 0.0
        if clear_treasure and same_target:
            backtrack_amount = max(current_path - prev_path, 0.0)
        elif (not clear_treasure) and guidance_exists and same_guidance:
            backtrack_amount = max(cur_guidance_dist - prev_guidance_dist, 0.0)
        r_treasure_backtrack = 0.0
        if (float(self.prev_raw_threat_score) - float(env_threat_score)) <= 0.02:
            r_treasure_backtrack = -Config.LAMBDA_TREASURE_BACKTRACK * backtrack_amount

        r_treasure_commit = 0.0
        if Config.LAMBDA_TREASURE_COMMIT > 0.0 and same_target and path_progress >= Config.TREASURE_COMMIT_PATH_PROGRESS_THR:
            r_treasure_commit = Config.LAMBDA_TREASURE_COMMIT * path_progress

        r_treasure_miss_close = 0.0
        if (
            target_treasure is not None
            and bool(target_treasure.get("walk_reachable_flag", False))
            and float(target_treasure.get("walk_path_len_norm", 1.0)) <= Config.TREASURE_NEAR_PATH_THR
            and greed_pressure_score <= Config.CLOSE_TREASURE_SAFETY_THR
            and local_open_score >= Config.CLOSE_TREASURE_OPEN_THR
            and delta_treasure == 0
            and path_progress <= 0.0
        ):
            r_treasure_miss_close = -Config.LAMBDA_TREASURE_MISS_CLOSE

        return {
            "r_treasure_collect": float(r_treasure_collect),
            "r_treasure_approach": float(r_treasure_approach),
            "r_treasure_guidance": float(r_treasure_guidance),
            "r_treasure_conflict_penalty": float(r_treasure_conflict_penalty),
            "r_treasure_backtrack": float(r_treasure_backtrack),
            "r_treasure_commit": float(r_treasure_commit),
            "r_treasure_miss_close": float(r_treasure_miss_close),
            "clear_treasure": bool(clear_treasure),
            "path_progress": float(path_progress),
            "guidance_exists": bool(guidance_exists),
            "guidance_progress": float(guidance_progress),
            "target_key": target_key,
            "guidance_key": guidance_key,
            "target_path_dist_norm": float(current_path),
            "guidance_dist_norm": float(cur_guidance_dist),
        }

    def _compute_flash_target_overshoot_risk(self, target_resource):
        overshoot_risk = np.zeros(8, dtype=np.float32)
        if target_resource is None:
            return overshoot_risk

        target_dir_vec = self._normalize_vec(target_resource["dir_vec"])
        if float(np.linalg.norm(target_dir_vec)) <= 1e-6:
            return overshoot_risk

        target_project_dist = float(target_resource["dist_norm"] * Config.RESOURCE_TARGET_DIST_NORM_DEN)
        for idx, flash_dir_vec in enumerate(MOVE_DIR_UNIT):
            align = float(np.dot(flash_dir_vec, target_dir_vec))
            if align < Config.FLASH_OVERSHOOT_ALIGN_THR:
                continue
            projected_target_dist = max(0.0, target_project_dist * align)
            overshoot_risk[idx] = float(
                max(0.0, (FLASH_RANGE[idx] - projected_target_dist) / max(float(FLASH_RANGE[idx]), 1.0))
            )
        return overshoot_risk

    def _compute_resource_decision_features(self, target_resource, flash_target_overshoot_risk):
        if target_resource is None:
            return np.zeros(Config.RESOURCE_DECISION_BLOCK, dtype=np.float32)

        target_dir_vec = self._normalize_vec(target_resource["dir_vec"])
        move_align = np.matmul(MOVE_DIR_UNIT, target_dir_vec)
        sorted_align = np.sort(move_align)
        target_move_collectable_flag = float(
            target_resource["walk_reachable_flag"]
            and target_resource["walk_path_len_norm"] <= Config.RESOURCE_NEAR_DIST_NORM_THR
        )
        return np.array(
            [
                1.0 if target_resource["sub_type"] == 1 else 0.0,
                1.0 if target_resource["sub_type"] == 2 else 0.0,
                float(target_resource["dist_norm"]),
                float(target_resource["value_score"]),
                float(target_resource["dx_norm"]),
                float(target_resource["dz_norm"]),
                float(sorted_align[-1]),
                float(sorted_align[-2]) if len(sorted_align) > 1 else float(sorted_align[-1]),
                float(np.max(flash_target_overshoot_risk)) if len(flash_target_overshoot_risk) > 0 else 0.0,
                target_move_collectable_flag,
                float(target_resource["walk_reachable_flag"]),
                float(target_resource["walk_path_len_norm"]),
                float(target_resource["line_blocked_flag"]),
                float(target_resource["flash_reachable_flag"]),
                float(target_resource["flash_best_score"]),
            ],
            dtype=np.float32,
        )

    def _parse_legal_action(self, legal_act_raw):
        legal_action = [1] * Config.ACTION_NUM
        if isinstance(legal_act_raw, list) and legal_act_raw:
            if isinstance(legal_act_raw[0], bool):
                for idx in range(min(Config.ACTION_NUM, len(legal_act_raw))):
                    legal_action[idx] = int(legal_act_raw[idx])
            else:
                valid_set = {int(action) for action in legal_act_raw if 0 <= int(action) < Config.ACTION_NUM}
                legal_action = [1 if idx in valid_set else 0 for idx in range(Config.ACTION_NUM)]
        if sum(legal_action) == 0:
            legal_action = [1] * Config.ACTION_NUM
        return legal_action

    def _apply_low_pressure_resource_move_mask(self, legal_action, target_resource, effective_pressure_score):
        refined_legal = list(legal_action)
        if (
            target_resource is None
            or not bool(target_resource.get("walk_reachable_flag", False))
            or float(effective_pressure_score) >= Config.PRESSURE_ALLOW_RESOURCE_MASK
        ):
            return refined_legal

        move_legal_indices = [idx for idx in range(8) if refined_legal[idx] == 1]
        if not move_legal_indices:
            return refined_legal

        target_dir_vec = self._normalize_vec(target_resource["dir_vec"])
        move_align = np.matmul(MOVE_DIR_UNIT, target_dir_vec)
        kept_indices = [idx for idx in move_legal_indices if float(move_align[idx]) > Config.RESOURCE_ALIGN_POS_THR]
        if len(kept_indices) < min(len(move_legal_indices), Config.RESOURCE_MOVE_MASK_KEEP_TOPK):
            ranked = sorted(move_legal_indices, key=lambda idx: float(move_align[idx]), reverse=True)
            for idx in ranked[: Config.RESOURCE_MOVE_MASK_KEEP_TOPK]:
                if idx not in kept_indices:
                    kept_indices.append(idx)

        if not kept_indices:
            return refined_legal

        for idx in range(8):
            refined_legal[idx] = 1 if idx in kept_indices and legal_action[idx] == 1 else 0
        if sum(refined_legal[:8]) == 0:
            return list(legal_action)
        return refined_legal

    def _compute_step_progress_components(
        self,
        *,
        new_reachable_road_ratio,
        current_treasures,
        last_treasures_before_update,
        current_buffs,
        last_buffs_before_update,
        target_resource,
        env_threat_score,
        local_open_score,
    ):
        explore_progress = float(np.clip(new_reachable_road_ratio, 0.0, 1.0))

        resource_progress = 0.0
        if current_treasures > last_treasures_before_update:
            resource_progress += 0.7
        if current_buffs > last_buffs_before_update:
            resource_progress += 0.5
        if (
            target_resource is not None
            and bool(target_resource.get("walk_reachable_flag", False))
            and self.prev_target_walk_reachable
        ):
            current_target_path_dist_norm = float(target_resource.get("walk_path_len_norm", target_resource.get("dist_norm", 1.0)))
            delta_target = float(self.prev_target_path_dist_norm) - current_target_path_dist_norm
            resource_progress += max(delta_target, 0.0)
        resource_progress = float(np.clip(resource_progress, 0.0, 1.0))

        safety_progress = float(np.clip(max(self.prev_raw_threat_score - env_threat_score, 0.0), 0.0, 1.0))

        open_gain = max(local_open_score - self.prev_local_open_score, 0.0)
        deadend_relief = max((1.0 - self.prev_local_open_score) - (1.0 - local_open_score), 0.0)
        topology_progress = float(np.clip(0.5 * open_gain + 0.5 * deadend_relief, 0.0, 1.0))

        total_progress = float(
            np.clip(
                Config.STALL_W_EXPLORE * explore_progress
                + Config.STALL_W_RESOURCE * resource_progress
                + Config.STALL_W_SAFETY * safety_progress
                + Config.STALL_W_TOPOLOGY * topology_progress,
                0.0,
                1.0,
            )
        )
        return {
            "explore_progress": explore_progress,
            "resource_progress": resource_progress,
            "safety_progress": safety_progress,
            "topology_progress": topology_progress,
            "total_progress": total_progress,
        }

    def _aggregate_progress_window(self, hist):
        if not hist:
            return {
                "avg_explore_progress": 0.0,
                "avg_resource_progress": 0.0,
                "avg_safety_progress": 0.0,
                "avg_topology_progress": 0.0,
                "avg_total_progress": 0.0,
            }
        size = float(len(hist))
        return {
            "avg_explore_progress": float(sum(item["explore_progress"] for item in hist) / size),
            "avg_resource_progress": float(sum(item["resource_progress"] for item in hist) / size),
            "avg_safety_progress": float(sum(item["safety_progress"] for item in hist) / size),
            "avg_topology_progress": float(sum(item["topology_progress"] for item in hist) / size),
            "avg_total_progress": float(sum(item["total_progress"] for item in hist) / size),
        }

    def _compute_stall_no_progress_penalty(self, greed_pressure_score):
        short_agg = self._aggregate_progress_window(self.progress_short_hist)
        mid_agg = self._aggregate_progress_window(self.progress_mid_hist)
        short_progress = float(short_agg["avg_total_progress"])
        mid_progress = float(mid_agg["avg_total_progress"])
        stall_gate = float(np.clip((1.0 - greed_pressure_score) ** Config.STALL_GATE_POWER, 0.0, 1.0))
        r_stall_no_progress_short = 0.0
        if Config.LAMBDA_STALL_NO_PROGRESS_SHORT > 0.0:
            r_stall_no_progress_short = (
                -Config.LAMBDA_STALL_NO_PROGRESS_SHORT
                * stall_gate
                * max(Config.STALL_PROGRESS_THR_SHORT - short_progress, 0.0)
            )
        r_stall_no_progress_mid = 0.0
        if Config.LAMBDA_STALL_NO_PROGRESS_MID > 0.0:
            r_stall_no_progress_mid = (
                -Config.LAMBDA_STALL_NO_PROGRESS_MID
                * stall_gate
                * max(Config.STALL_PROGRESS_THR_MID - mid_progress, 0.0)
            )
        return r_stall_no_progress_short, r_stall_no_progress_mid, short_progress, mid_progress

    def _simulate_one_step_move_state(
        self,
        map_info,
        hero_pos,
        move_idx,
        monsters,
        target_resource,
        current_env_threat_score,
        current_local_open_score,
        explore_dir_gain,
        time_to_monster2_ratio,
        time_to_monster_speedup_ratio,
        is_flash_avail,
        has_buff,
        runtime_cfg,
    ):
        if map_info is None or move_idx < 0 or move_idx >= 8:
            return {"valid": False}
        center = self._get_local_center(map_info)
        if center is None:
            return {"valid": False}
        dr, dc = FLASH_DIR_RC[move_idx]
        next_row = center[0] + dr
        next_col = center[1] + dc
        if not self._is_passable(map_info, next_row, next_col):
            return {"valid": False}
        if not self._is_diag_move_valid(map_info, center[0], center[1], next_row, next_col):
            return {"valid": False}

        hero_pos_next = self._local_cell_to_world_pos(hero_pos, next_row, next_col, map_info)
        reach_metrics = self._compute_min_monster_reach_metrics(
            map_info=map_info,
            hero_pos=hero_pos_next,
            monsters=monsters,
            map_anchor_pos=hero_pos,
        )
        predicted_open_score = self._compute_cell_open_score(map_info, (next_row, next_col))
        predicted_env_threat_score, _, _ = self._compute_pressure_scores_v2(
            min_reach_time_visible=reach_metrics["min_reach_time_visible"],
            min_reach_time_all=reach_metrics["min_reach_time_all"],
            monsters=monsters,
            time_to_monster2_ratio=time_to_monster2_ratio,
            time_to_monster_speedup_ratio=time_to_monster_speedup_ratio,
            local_open_score=predicted_open_score,
            is_flash_avail=is_flash_avail,
            has_buff=has_buff,
            runtime_cfg=runtime_cfg,
        )
        predicted_deadend_risk = float(1.0 - predicted_open_score)
        predicted_target_path_progress = 0.0
        if (
            target_resource is not None
            and bool(target_resource.get("walk_reachable_flag", False))
            and target_resource.get("local_cell") is not None
        ):
            reachable, next_path_len = self._bfs_local_path_distance(map_info, (next_row, next_col), target_resource["local_cell"])
            if reachable and next_path_len is not None:
                next_path_norm = float(
                    np.clip(float(next_path_len) / max(float(Config.TREASURE_REACH_DIST_NORM_DEN), 1.0), 0.0, 1.0)
                )
                current_path_norm = float(target_resource.get("walk_path_len_norm", target_resource.get("dist_norm", 1.0)))
                predicted_target_path_progress = max(current_path_norm - next_path_norm, 0.0)
        predicted_explore_gain = float(explore_dir_gain[move_idx]) if 0 <= move_idx < len(explore_dir_gain) else 0.0
        predicted_topology_gain = max(predicted_open_score - current_local_open_score, 0.0)
        predicted_safety_gain = max(current_env_threat_score - predicted_env_threat_score, 0.0)
        return {
            "valid": True,
            "hero_pos_next": hero_pos_next,
            "predicted_env_threat_score": float(predicted_env_threat_score),
            "predicted_local_open_score": float(predicted_open_score),
            "predicted_deadend_risk": float(predicted_deadend_risk),
            "predicted_target_path_progress": float(predicted_target_path_progress),
            "predicted_explore_gain": float(predicted_explore_gain),
            "predicted_topology_gain": float(predicted_topology_gain),
            "predicted_safety_gain": float(predicted_safety_gain),
        }

    def _compute_move_dir_progress_scores(
        self,
        map_info,
        hero_pos,
        monsters,
        target_resource,
        current_env_threat_score,
        current_local_open_score,
        explore_dir_gain,
        legal_action,
        time_to_monster2_ratio,
        time_to_monster_speedup_ratio,
        is_flash_avail,
        has_buff,
        runtime_cfg,
    ):
        dir_progress_scores = np.zeros(8, dtype=np.float32)
        predicted_dir_open_scores = np.full(8, current_local_open_score, dtype=np.float32)
        predicted_dir_threat_scores = np.full(8, current_env_threat_score, dtype=np.float32)
        dir_explore_gain = np.zeros(8, dtype=np.float32)
        dir_resource_progress = np.zeros(8, dtype=np.float32)
        dir_topology_gain = np.zeros(8, dtype=np.float32)

        for idx in range(8):
            if legal_action is not None and (len(legal_action) <= idx or float(legal_action[idx]) <= 0.0):
                continue
            sim_result = self._simulate_one_step_move_state(
                map_info=map_info,
                hero_pos=hero_pos,
                move_idx=idx,
                monsters=monsters,
                target_resource=target_resource,
                current_env_threat_score=current_env_threat_score,
                current_local_open_score=current_local_open_score,
                explore_dir_gain=explore_dir_gain,
                time_to_monster2_ratio=time_to_monster2_ratio,
                time_to_monster_speedup_ratio=time_to_monster_speedup_ratio,
                is_flash_avail=is_flash_avail,
                has_buff=has_buff,
                runtime_cfg=runtime_cfg,
            )
            if not sim_result["valid"]:
                continue
            predicted_dir_open_scores[idx] = sim_result["predicted_local_open_score"]
            predicted_dir_threat_scores[idx] = sim_result["predicted_env_threat_score"]
            dir_explore_gain[idx] = sim_result["predicted_explore_gain"]
            dir_resource_progress[idx] = sim_result["predicted_target_path_progress"]
            dir_topology_gain[idx] = sim_result["predicted_topology_gain"]
            predicted_safety_gain = sim_result["predicted_safety_gain"]
            dir_progress_scores[idx] = float(
                np.clip(
                    Config.DIR_PROGRESS_W_EXPLORE * dir_explore_gain[idx]
                    + Config.DIR_PROGRESS_W_RESOURCE * dir_resource_progress[idx]
                    + Config.DIR_PROGRESS_W_SAFETY * predicted_safety_gain
                    + Config.DIR_PROGRESS_W_TOPOLOGY * dir_topology_gain[idx],
                    0.0,
                    1.0,
                )
            )

        best_dir_progress = float(np.max(dir_progress_scores)) if len(dir_progress_scores) > 0 else 0.0
        self._latest_dir_explore_gain = dir_explore_gain.astype(np.float32)
        self._latest_dir_resource_progress = dir_resource_progress.astype(np.float32)
        self._latest_dir_topology_gain = dir_topology_gain.astype(np.float32)
        self.prev_dir_progress_scores = dir_progress_scores.astype(np.float32)
        return (
            dir_progress_scores.astype(np.float32),
            best_dir_progress,
            predicted_dir_open_scores.astype(np.float32),
            predicted_dir_threat_scores.astype(np.float32),
        )

    def _apply_no_progress_weak_move_mask(
        self,
        legal_action,
        dir_progress_scores,
        best_dir_progress,
        predicted_dir_open_scores,
        predicted_dir_threat_scores,
        topology_ray_feat,
        target_resource,
        greed_pressure_score,
        current_env_threat_score,
    ):
        refined_legal = np.array(legal_action, dtype=np.float32, copy=True)
        if not Config.ENABLE_SOFT_MOVE_MASK:
            return refined_legal.astype(np.float32)
        if greed_pressure_score > Config.SOFT_MOVE_MASK_LOW_PRESSURE_THR:
            return refined_legal.astype(np.float32)
        if current_env_threat_score > Config.SOFT_MOVE_MASK_ESCAPE_PRESSURE_THR:
            return refined_legal.astype(np.float32)
        if self._has_clear_reachable_target_resource(target_resource):
            return refined_legal.astype(np.float32)

        for idx in range(8):
            if refined_legal[idx] <= 0.0:
                continue
            wall_near_flag = float(topology_ray_feat[idx]) <= float(Config.SOFT_MOVE_MASK_WALL_RAY_THR / 10.0)
            low_progress_flag = (
                float(dir_progress_scores[idx]) <= Config.DIR_PROGRESS_LOW_THR
                or (float(best_dir_progress) - float(dir_progress_scores[idx])) >= Config.DIR_PROGRESS_MARGIN_TO_BEST
            )
            no_real_benefit_flag = (
                float(predicted_dir_threat_scores[idx]) >= float(current_env_threat_score) - Config.SOFT_MOVE_MASK_SAFETY_TOL
                and float(self._latest_dir_explore_gain[idx]) <= Config.SOFT_MOVE_MASK_EXPLORE_TOL
                and float(self._latest_dir_resource_progress[idx]) <= Config.SOFT_MOVE_MASK_RESOURCE_TOL
                and float(self._latest_dir_topology_gain[idx]) <= Config.SOFT_MOVE_MASK_TOPOLOGY_TOL
            )
            if not (wall_near_flag and low_progress_flag and no_real_benefit_flag):
                continue

            if float(dir_progress_scores[idx]) <= max(Config.DIR_PROGRESS_LOW_THR * 0.5, 0.05):
                refined_legal[idx] = min(refined_legal[idx], float(Config.SOFT_MOVE_MASK_MIN_WEIGHT))
            else:
                refined_legal[idx] = min(refined_legal[idx], float(Config.SOFT_MOVE_MASK_MID_WEIGHT))

        return refined_legal.astype(np.float32)

    def _compute_near_treasure_features(
        self,
        treasure_exist,
        treasure_effective_dist_norm,
        effective_pressure_score,
        local_deadend_risk,
        flash_direction_info,
        treasure_walk_reachable_flag,
        treasure_walk_path_len_norm,
        treasure_line_blocked_flag,
        treasure_flash_reachable_flag,
    ):
        treasure_deadend_cost = float(
            treasure_exist * local_deadend_risk * max(0.0, 1.0 - float(treasure_effective_dist_norm))
        )
        treasure_deadend_cost = float(np.clip(treasure_deadend_cost, 0.0, 1.0))
        if treasure_exist <= 0.0:
            near_treasure_collectability = 0.0
        elif treasure_walk_reachable_flag:
            near_treasure_collectability = float(
                (1.0 / (1.0 + float(treasure_walk_path_len_norm)))
                * (1.0 - effective_pressure_score)
                * (1.0 - treasure_deadend_cost)
                * (1.0 - 0.35 * float(treasure_line_blocked_flag))
            )
        elif treasure_flash_reachable_flag:
            near_treasure_collectability = float(
                0.45
                * (1.0 / (1.0 + float(treasure_effective_dist_norm)))
                * (1.0 - effective_pressure_score)
                * (1.0 - treasure_deadend_cost)
            )
        else:
            near_treasure_collectability = float(
                0.12
                * (1.0 / (1.0 + float(treasure_effective_dist_norm)))
                * (1.0 - effective_pressure_score)
                * (1.0 - treasure_deadend_cost)
            )

        max_flash_path_resource_gain = float(np.max(flash_direction_info["path_resource_gain"])) if len(
            flash_direction_info["path_resource_gain"]
        ) > 0 else 0.0
        flash_skip_near_treasure_risk = float(
            max(0.0, near_treasure_collectability - max_flash_path_resource_gain)
        )

        flash_value_proxy = (
            0.5 * np.maximum(flash_direction_info["safe_gain"], 0.0)
            + 0.3 * flash_direction_info["path_resource_gain"]
            + 0.2 * flash_direction_info["landing_open_score"]
        )
        max_flash_value_proxy = float(np.max(flash_value_proxy)) if len(flash_value_proxy) > 0 else 0.0
        flash_opportunity_cost = float(max(0.0, near_treasure_collectability - max_flash_value_proxy))

        feature = np.array(
            [
                near_treasure_collectability,
                treasure_deadend_cost,
                flash_skip_near_treasure_risk,
                flash_opportunity_cost,
            ],
            dtype=np.float32,
        )
        return feature, near_treasure_collectability, flash_opportunity_cost

    def _compute_buff_strategy_features(self, hero_pos, runtime_cfg, effective_pressure_score, current_treasures):
        total_treasure_cfg = max(float(runtime_cfg["treasure_count"]), 1.0)
        remaining_treasure_ratio = float(
            max(total_treasure_cfg - float(current_treasures), 0.0) / total_treasure_cfg
        )
        treasure_scarcity = float(1.0 - remaining_treasure_ratio)

        known_buff_points = np.argwhere(self.global_buff_mask == 1)
        if known_buff_points.size == 0:
            return np.array([remaining_treasure_ratio, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32), None

        buff_cooldown_cfg = max(float(runtime_cfg["buff_cooldown"]), 1.0)
        candidates = []
        for point_x, point_z in known_buff_points:
            point_x = int(point_x)
            point_z = int(point_z)
            buff_cd = float(self.global_buff_cd[point_x, point_z])
            dist = math.sqrt((float(point_x) - hero_pos["x"]) ** 2 + (float(point_z) - hero_pos["z"]) ** 2)
            candidates.append(
                {
                    "key": (point_x, point_z),
                    "point": (point_x, point_z),
                    "buff_cd": buff_cd,
                    "dist": float(dist),
                }
            )

        ready_buffs = [candidate for candidate in candidates if candidate["buff_cd"] <= 0.0]
        if ready_buffs:
            target_buff = min(ready_buffs, key=lambda item: item["dist"])
        else:
            min_cd = min(candidate["buff_cd"] for candidate in candidates)
            close_cd_candidates = [
                candidate
                for candidate in candidates
                if candidate["buff_cd"] <= min_cd + float(Config.BUFF_TARGET_CD_TIE_MARGIN)
            ]
            target_buff = min(close_cd_candidates, key=lambda item: (item["buff_cd"], item["dist"]))

        target_x, target_z = target_buff["point"]
        target_buff_dist_norm = float(np.clip(target_buff["dist"] / 40.0, 0.0, 1.0))
        if target_buff["buff_cd"] <= 0.0:
            target_buff_ready_score = float(Config.BUFF_TARGET_READY_SCORE_READY)
        else:
            target_buff_ready_score = float(
                np.clip(
                    1.0 - target_buff["buff_cd"] / buff_cooldown_cfg,
                    float(Config.BUFF_TARGET_READY_SCORE_MIN),
                    float(Config.BUFF_TARGET_READY_SCORE_READY),
                )
            )

        target_buff_dx_norm = float(np.clip((target_x - hero_pos["x"]) / 40.0, -1.0, 1.0))
        target_buff_dz_norm = float(np.clip((target_z - hero_pos["z"]) / 40.0, -1.0, 1.0))
        target_buff_value_score = float(
            effective_pressure_score
            * treasure_scarcity
            * target_buff_ready_score
            / (target_buff["dist"] + Config.BUFF_APPROACH_DISTANCE_EPS)
        )

        feature = np.array(
            [
                remaining_treasure_ratio,
                target_buff_value_score,
                target_buff_dx_norm,
                target_buff_dz_norm,
                target_buff_ready_score,
                target_buff_dist_norm,
            ],
            dtype=np.float32,
        )
        target_buff_info = {
            "key": target_buff["key"],
            "dist_norm": target_buff_dist_norm,
            "ready_score": target_buff_ready_score,
            "treasure_scarcity": treasure_scarcity,
            "value_score": target_buff_value_score,
        }
        return feature, target_buff_info

    def feature_process(self, env_obs, last_action):
        observation = env_obs["observation"]
        frame_state = observation["frame_state"]
        env_info = observation["env_info"]
        map_info = observation["map_info"]
        legal_act_raw = observation["legal_action"]
        runtime_cfg = self._get_runtime_cfg(env_info)

        self.step_no = self._safe_int(observation.get("step_no", 0), 0)
        self.max_step = runtime_cfg["max_step"]
        last_action = self._safe_int(last_action, -1)

        current_treasures = self._safe_int(env_info.get("treasures_collected", 0), 0)
        current_buffs = self._safe_int(env_info.get("collected_buff", 0), 0)

        # 1) hero_core_block
        hero = frame_state["heroes"]
        hero_pos = hero["pos"]
        hero_x_idx, hero_z_idx = self._get_grid_pos(hero_pos)
        flash_cd = hero.get("flash_cooldown", 0)
        buff_time = hero.get("buff_remaining_time", 0)
        is_flash_avail = float(flash_cd == 0)
        has_buff = float(buff_time > 0)
        hero_feat = np.array(
            [
                _norm(hero_pos["x"], MAP_SIZE),
                _norm(hero_pos["z"], MAP_SIZE),
                _norm(buff_time, MAX_BUFF_DURATION),
                is_flash_avail,
                has_buff,
            ],
            dtype=np.float32,
        )

        # 2) monster_block，同时维护 visible / all 两套最近距离。
        monsters = frame_state.get("monsters", [])
        monster_feats, visible_raw_dists, all_raw_dists = [], [], []
        for idx in range(2):
            if idx < len(monsters):
                monster = monsters[idx]
                is_in_view = float(monster.get("is_in_view", 0))
                m_speed_norm = _norm(monster.get("speed", 1), MAX_MONSTER_SPEED)
                if is_in_view:
                    monster_pos = monster["pos"]
                    dx = monster_pos["x"] - hero_pos["x"]
                    dz = monster_pos["z"] - hero_pos["z"]
                    raw_dist = math.sqrt(dx**2 + dz**2)
                    dx_norm = float(np.clip(dx / 40.0, -1.0, 1.0))
                    dz_norm = float(np.clip(dz / 40.0, -1.0, 1.0))
                    visible_raw_dists.append(raw_dist)
                else:
                    direction = monster.get("hero_relative_direction", 0)
                    bucket = monster.get("hero_l2_distance", 5)
                    monster_pos = self._estimate_entity_pos_from_relative(hero_pos, direction, bucket)
                    raw_dist = self._estimate_bucket_distance(bucket)
                    dir_vec = DIR_MAP.get(direction, (0.0, 0.0))
                    dx_norm, dz_norm = dir_vec[0], dir_vec[1]

                dist_norm = float(np.clip(raw_dist / 40.0, 0.0, 1.0))
                monster_feats.append(
                    np.array([is_in_view, dx_norm, dz_norm, m_speed_norm, dist_norm], dtype=np.float32)
                )
                all_raw_dists.append(raw_dist)
            else:
                monster_feats.append(np.zeros(5, dtype=np.float32))

        cur_min_dist_raw_visible = min(visible_raw_dists) if visible_raw_dists else 100.0
        cur_min_dist_raw_all = min(all_raw_dists) if all_raw_dists else 100.0

        # 3) resource_radar_block
        organs = frame_state.get("organs", [])
        treasure_exist, t_dx_norm, t_dz_norm, t_dist_bucket = 0.0, 0.0, 0.0, 5.0
        buff_exist, b_dx_norm, b_dz_norm, b_dist_bucket = 0.0, 0.0, 0.0, 5.0
        t_direction = 0
        min_t_bucket = 999
        min_b_bucket = 999
        for organ in organs:
            if organ.get("status", 1) != 1:
                continue
            direction = organ.get("hero_relative_direction", 0)
            bucket = organ.get("hero_l2_distance", 5)
            dir_vec = DIR_MAP.get(direction, (0.0, 0.0))
            if organ.get("sub_type") == 1 and bucket < min_t_bucket:
                treasure_exist = 1.0
                min_t_bucket = bucket
                t_direction = direction
                t_dx_norm, t_dz_norm, t_dist_bucket = dir_vec[0], dir_vec[1], bucket
            elif organ.get("sub_type") == 2 and bucket < min_b_bucket:
                buff_exist = 1.0
                min_b_bucket = bucket
                b_dx_norm, b_dz_norm, b_dist_bucket = dir_vec[0], dir_vec[1], bucket

        treasure_dist_norm = t_dist_bucket / 5.0 if treasure_exist > 0 else 1.0
        buff_dist_norm = b_dist_bucket / 5.0 if buff_exist > 0 else 1.0
        treasure_feat = np.array([treasure_exist, t_dx_norm, t_dz_norm, treasure_dist_norm], dtype=np.float32)
        buff_feat = np.array([buff_exist, b_dx_norm, b_dz_norm, buff_dist_norm], dtype=np.float32)
        resource_radar_feat = np.concatenate([treasure_feat, buff_feat]).astype(np.float32)

        # 4) topology_block
        ray_feat = np.zeros(8, dtype=np.float32)
        if map_info is not None and len(map_info) > 0 and len(map_info[0]) > 0:
            center_row = len(map_info) // 2
            center_col = len(map_info[0]) // 2
            for idx, (dr, dc) in enumerate(FLASH_DIR_RC):
                row, col, dist = center_row, center_col, 0.0
                for _ in range(10):
                    row += dr
                    col += dc
                    if self._is_passable(map_info, row, col):
                        dist += 1.0
                    else:
                        break
                ray_feat[idx] = float(dist / 10.0)

        local_open_score = float(np.mean(ray_feat))
        local_deadend_risk = float(1.0 - local_open_score)
        topology_extra_feat = np.array([local_open_score], dtype=np.float32)

        # 5) flash_stage_global_block
        flash_cd_ratio_cfg = float(np.clip(flash_cd / max(float(runtime_cfg["talent_cooldown"]), 1.0), 0.0, 1.0))
        time_to_monster2_ratio = float(
            max(float(runtime_cfg["monster_interval"]) - float(self.step_no), 0.0)
            / max(float(runtime_cfg["monster_interval"]), 1.0)
        )
        time_to_monster_speedup_ratio = float(
            max(float(runtime_cfg["monster_speedup"]) - float(self.step_no), 0.0)
            / max(float(runtime_cfg["monster_speedup"]), 1.0)
        )
        reach_metrics = self._compute_min_monster_reach_metrics(
            map_info=map_info,
            hero_pos=hero_pos,
            monsters=monsters,
        )
        cur_min_reach_dist_visible = float(reach_metrics["min_reach_dist_visible"])
        cur_min_reach_time_visible = float(reach_metrics["min_reach_time_visible"])
        cur_min_reach_dist_all = float(reach_metrics["min_reach_dist_all"])
        cur_min_reach_time_all = float(reach_metrics["min_reach_time_all"])
        raw_threat_score, flash_decision_pressure, effective_pressure_score = self._compute_pressure_scores_v2(
            min_reach_time_visible=cur_min_reach_time_visible,
            min_reach_time_all=cur_min_reach_time_all,
            monsters=monsters,
            time_to_monster2_ratio=time_to_monster2_ratio,
            time_to_monster_speedup_ratio=time_to_monster_speedup_ratio,
            local_open_score=local_open_score,
            is_flash_avail=is_flash_avail,
            has_buff=has_buff,
            runtime_cfg=runtime_cfg,
        )
        survive_pressure_score = effective_pressure_score
        flash_stage_global_feat = np.array(
            [
                flash_cd_ratio_cfg,
                time_to_monster2_ratio,
                time_to_monster_speedup_ratio,
                raw_threat_score,
                effective_pressure_score,
            ],
            dtype=np.float32,
        )

        # 6) flash_direction_block
        flash_direction_info = self._compute_flash_direction_features(
            map_info=map_info,
            hero_pos=hero_pos,
            monsters=monsters,
            organs=organs,
            runtime_cfg=runtime_cfg,
            time_to_monster2_ratio=time_to_monster2_ratio,
            time_to_monster_speedup_ratio=time_to_monster_speedup_ratio,
            is_flash_avail=is_flash_avail,
            has_buff=has_buff,
            current_flash_decision_pressure=flash_decision_pressure,
        )
        flash_direction_feat = flash_direction_info["feature"]
        target_treasure = self._select_visible_target_treasure(
            organs=organs,
            hero_pos=hero_pos,
            map_info=map_info,
            flash_direction_info=flash_direction_info,
        )
        if target_treasure is not None:
            target_resource = target_treasure
        else:
            target_resource = self._select_visible_target_resource(
                organs=organs,
                hero_pos=hero_pos,
                map_info=map_info,
                flash_direction_info=flash_direction_info,
                effective_pressure_score=effective_pressure_score,
                allowed_sub_types={2},
            )
        target_treasure_resource = target_treasure
        treasure_guidance = self._build_treasure_guidance(organs, hero_pos, target_treasure)
        flash_target_overshoot_risk = self._compute_flash_target_overshoot_risk(target_resource)
        # exploration 奖励不再统计“新看到多少未知格”，而只统计“当前可达拓扑下新打开多少道路格”。
        new_reachable_metrics = self._compute_new_reachable_road_metrics(hero_pos, map_info)
        new_reachable_road_ratio = float(new_reachable_metrics["new_reachable_road_ratio"])
        explore_dir_gain, best_explore_dir_gain, second_explore_dir_gain, reachable_frontier_density = self._compute_explore_direction_gains(
            hero_pos, map_info
        )
        if map_info is not None and len(map_info) > 0 and len(map_info[0]) > 0:
            reachable_frontier_density = float(new_reachable_metrics["reachable_frontier_density"])
        step_progress_components = self._compute_step_progress_components(
            new_reachable_road_ratio=new_reachable_road_ratio,
            current_treasures=current_treasures,
            last_treasures_before_update=self.last_treasures,
            current_buffs=current_buffs,
            last_buffs_before_update=self.last_buffs,
            target_resource=target_resource,
            env_threat_score=raw_threat_score,
            local_open_score=local_open_score,
        )
        self.progress_short_hist.append(step_progress_components)
        self.progress_mid_hist.append(step_progress_components)

        # 先更新地形 / buff 记忆，但不提前更新 visit / last_visit。
        self._update_global_maps(hero_pos, map_info, organs, runtime_cfg)

        # 7) stagnation_block
        no_visible_goal_flag = float(treasure_exist == 0.0 and buff_exist == 0.0)
        prev_visit_count_current_cell = int(self.global_visit[hero_x_idx, hero_z_idx])
        last_visit_step = int(self.global_last_visit[hero_x_idx, hero_z_idx])
        if last_visit_step <= NEG_INF_VISIT // 2:
            exact_cell_revisit_score = 0.0
        else:
            exact_cell_revisit_score = float(
                math.exp(-(float(self.step_no) - float(last_visit_step)) / max(float(Config.TAU_RECENT_REVISIT), 1.0))
            )

        if len(self.recent_positions) < 2:
            recent_loop_ratio = 0.0
        else:
            unique_count = len(set(self.recent_positions))
            recent_loop_ratio = float(1.0 - unique_count / max(len(self.recent_positions), 1))

        if self.last_hero_pos is None:
            current_step_dist = 0.0
        else:
            current_step_dist = math.sqrt(
                (float(hero_pos["x"]) - float(self.last_hero_pos["x"])) ** 2
                + (float(hero_pos["z"]) - float(self.last_hero_pos["z"])) ** 2
            )
        local_recent_revisit_score = self._compute_local_recent_revisit_score(hero_x_idx, hero_z_idx)
        path_efficiency = self._compute_path_efficiency(
            current_pos=(hero_x_idx, hero_z_idx),
            current_step_dist=current_step_dist,
        )
        loop_closure_short, loop_closure_mid = self._compute_loop_closure_scores(
            current_pos=(hero_x_idx, hero_z_idx)
        )
        frontier_dir_score = self._compute_frontier_dir_scores(hero_pos)
        stagnation_feat = np.concatenate(
            [
                np.array(
                    [
                        no_visible_goal_flag,
                        exact_cell_revisit_score,
                        recent_loop_ratio,
                        local_recent_revisit_score,
                        path_efficiency,
                        loop_closure_short,
                        loop_closure_mid,
                    ],
                    dtype=np.float32,
                ),
                frontier_dir_score,
            ]
        ).astype(np.float32)

        # 8) near_treasure_block
        near_treasure_feat, near_treasure_collectability, _ = self._compute_near_treasure_features(
            treasure_exist=1.0 if target_treasure_resource is not None else 0.0,
            treasure_effective_dist_norm=float(target_treasure_resource["dist_norm"]) if target_treasure_resource else 1.0,
            effective_pressure_score=effective_pressure_score,
            local_deadend_risk=local_deadend_risk,
            flash_direction_info=flash_direction_info,
            treasure_walk_reachable_flag=bool(target_treasure_resource["walk_reachable_flag"]) if target_treasure_resource else False,
            treasure_walk_path_len_norm=float(target_treasure_resource["walk_path_len_norm"]) if target_treasure_resource else 1.0,
            treasure_line_blocked_flag=float(target_treasure_resource["line_blocked_flag"]) if target_treasure_resource else 0.0,
            treasure_flash_reachable_flag=bool(target_treasure_resource["flash_reachable_flag"]) if target_treasure_resource else False,
        )

        # 9) resource_decision_block
        resource_decision_feat = self._compute_resource_decision_features(
            target_resource, flash_target_overshoot_risk
        )

        # 10) exploration_block
        exploration_feat = np.concatenate(
            [
                np.array(
                    [
                        new_reachable_road_ratio,
                        reachable_frontier_density,
                        best_explore_dir_gain,
                        second_explore_dir_gain,
                    ],
                    dtype=np.float32,
                ),
                explore_dir_gain.astype(np.float32),
            ]
        ).astype(np.float32)

        # 11) buff_strategy_block
        buff_strategy_feat, target_buff_info = self._compute_buff_strategy_features(
            hero_pos=hero_pos,
            runtime_cfg=runtime_cfg,
            effective_pressure_score=effective_pressure_score,
            current_treasures=current_treasures,
        )

        # 12) legal_action mask（保留计算，但不拼接进 feature）
        base_legal_action = self._parse_legal_action(legal_act_raw)
        (
            dir_progress_scores,
            best_dir_progress,
            predicted_dir_open_scores,
            predicted_dir_threat_scores,
        ) = self._compute_move_dir_progress_scores(
            map_info=map_info,
            hero_pos=hero_pos,
            monsters=monsters,
            target_resource=target_resource,
            current_env_threat_score=raw_threat_score,
            current_local_open_score=local_open_score,
            explore_dir_gain=explore_dir_gain,
            legal_action=base_legal_action,
            time_to_monster2_ratio=time_to_monster2_ratio,
            time_to_monster_speedup_ratio=time_to_monster_speedup_ratio,
            is_flash_avail=is_flash_avail,
            has_buff=has_buff,
            runtime_cfg=runtime_cfg,
        )
        legal_action = list(base_legal_action)
        legal_action = self._apply_low_pressure_resource_move_mask(
            legal_action=legal_action,
            target_resource=target_resource,
            effective_pressure_score=effective_pressure_score,
        )
        if Config.ENABLE_SOFT_MOVE_MASK:
            legal_action = self._apply_no_progress_weak_move_mask(
                legal_action=legal_action,
                dir_progress_scores=dir_progress_scores,
                best_dir_progress=best_dir_progress,
                predicted_dir_open_scores=predicted_dir_open_scores,
                predicted_dir_threat_scores=predicted_dir_threat_scores,
                topology_ray_feat=ray_feat,
                target_resource=target_resource,
                greed_pressure_score=effective_pressure_score,
                current_env_threat_score=raw_threat_score,
            )
        legal_action = self._apply_close_treasure_soft_bias(
            legal_action=legal_action,
            target_treasure=target_treasure,
            greed_pressure_score=effective_pressure_score,
            local_open_score=local_open_score,
        )

        # 13) progress_block
        step_norm = _norm(self.step_no, self.max_step)
        progress_feat = np.array([step_norm], dtype=np.float32)

        # 14) map_view_block，仍然放在最后。
        map_feat = np.zeros(Config.MAP_FEAT_DIM, dtype=np.float32)
        try:
            if map_info is not None and len(map_info) > 0 and len(map_info[0]) > 0:
                center_row = len(map_info) // 2
                center_col = len(map_info[0]) // 2
                radius = Config.VIEW_RADIUS
                flat_idx = 0
                for row in range(center_row - radius, center_row + radius + 1):
                    for col in range(center_col - radius, center_col + radius + 1):
                        if self._is_passable(map_info, row, col):
                            map_feat[flat_idx] = 1.0
                        flat_idx += 1
        except (TypeError, IndexError, KeyError):
            map_feat = np.zeros(Config.MAP_FEAT_DIM, dtype=np.float32)

        feature = np.concatenate(
            [
                hero_feat,
                flash_stage_global_feat,
                monster_feats[0],
                monster_feats[1],
                resource_radar_feat,
                ray_feat,
                topology_extra_feat,
                stagnation_feat,
                near_treasure_feat,
                resource_decision_feat,
                exploration_feat,
                flash_direction_feat,
                buff_strategy_feat,
                progress_feat,
                map_feat,
            ]
        ).astype(np.float32)

        if feature.shape[0] != Config.FEATURE_LEN:
            raise ValueError(f"feature dim mismatch: got {feature.shape[0]}, expect {Config.FEATURE_LEN}")

        # -------------------- Reward：逐项定义 -> 最终求和 --------------------
        prev_min_reach_time_visible = self.prev_min_monster_reach_time_visible
        prev_flash_pressure = self.prev_flash_decision_pressure
        last_treasures_before_update = self.last_treasures
        last_buffs_before_update = self.last_buffs

        delta_treasure = max(current_treasures - last_treasures_before_update, 0)
        delta_buff = max(current_buffs - last_buffs_before_update, 0)

        # 已有基础项
        r_survive = 0.01
        if flash_decision_pressure > 0.75:
            r_danger = -0.5
        elif flash_decision_pressure > 0.45:
            r_danger = -0.2
        else:
            r_danger = 0.0

        r_escape = 0.0
        if prev_min_reach_time_visible is not None:
            r_escape = float(np.clip(prev_min_reach_time_visible - cur_min_reach_time_visible, -1.0, 1.0) * 0.08)

        r_treasure = Config.TREASURE_REWARD_BASE if current_treasures > last_treasures_before_update else 0.0
        r_buff = Config.BUFF_REWARD_BASE if current_buffs > last_buffs_before_update else 0.0

        r_align = 0.0
        if (
            Config.LAMBDA_ALIGN > 0.0
            and target_treasure is not None
            and self.last_hero_pos is not None
            and delta_treasure == 0
            and 0 <= last_action <= 7
        ):
            move_dx = hero_pos["x"] - self.last_hero_pos["x"]
            move_dz = hero_pos["z"] - self.last_hero_pos["z"]
            move_vec = self._normalize_vec(np.array([move_dx, move_dz], dtype=np.float32))
            target_vec = self._normalize_vec(target_treasure["dir_vec"])
            if float(np.linalg.norm(move_vec)) > 1e-6 and float(np.linalg.norm(target_vec)) > 1e-6:
                align = float(np.dot(move_vec, target_vec))
                align_reward = max(
                    (align - float(Config.RESOURCE_ALIGN_POS_THR))
                    / max(1.0 - float(Config.RESOURCE_ALIGN_POS_THR), 1e-6),
                    0.0,
                )
                r_align = float(
                    Config.LAMBDA_ALIGN
                    * 0.05
                    * (1.0 - effective_pressure_score)
                    * align_reward
                )

        r_wall = 0.0
        if self.last_hero_pos is not None:
            move_dx = hero_pos["x"] - self.last_hero_pos["x"]
            move_dz = hero_pos["z"] - self.last_hero_pos["z"]
            if move_dx == 0 and move_dz == 0 and 0 <= last_action <= 7:
                r_wall = -0.2

        # Flash V1 已有 reward
        r_flash_escape = 0.0
        r_flash_cross_wall = 0.0
        r_flash_low_burn = 0.0
        r_flash_unnecessary = 0.0
        r_flash_landing_bad = 0.0

        # 本次新增 reward
        has_high_value_resource_target = float(
            target_resource is not None
            and (bool(target_resource["walk_reachable_flag"]) or bool(target_resource["flash_reachable_flag"]))
            and (
                float(target_resource["dist_norm"]) <= 0.35
                or float(target_resource["value_score"]) >= 0.6
            )
        )
        visible_monster_exists = any(
            isinstance(monster, dict)
            and isinstance(monster.get("pos"), dict)
            and "x" in monster["pos"]
            and "z" in monster["pos"]
            for monster in monsters or []
        )
        explore_hard_gate = float((not visible_monster_exists) and treasure_exist == 0.0 and buff_exist == 0.0)
        resource_suppress = 0.35 if has_high_value_resource_target > 0.0 else (0.5 if (treasure_exist > 0.0 or buff_exist > 0.0) else 1.0)
        idle_gate = no_visible_goal_flag * (1.0 - effective_pressure_score) * resource_suppress
        r_stall_no_progress_short, r_stall_no_progress_mid, _, _ = self._compute_stall_no_progress_penalty(
            effective_pressure_score
        )
        old_reg_scale = float(Config.STALL_OLD_REG_SCALE)
        r_recent_revisit = -Config.LAMBDA_RECENT_REVISIT * idle_gate * exact_cell_revisit_score * old_reg_scale
        r_loop = 0.0
        if Config.LAMBDA_LOOP > 0.0:
            r_loop = -Config.LAMBDA_LOOP * idle_gate * max(0.0, recent_loop_ratio - Config.TAU_LOOP) * old_reg_scale
        r_frontier = 0.0
        if Config.LAMBDA_FRONTIER > 0.0:
            r_frontier = Config.LAMBDA_FRONTIER * idle_gate * (1.0 / math.sqrt(1.0 + prev_visit_count_current_cell))
        r_local_region_revisit = 0.0
        if Config.LAMBDA_LOCAL_REGION_REVISIT > 0.0:
            r_local_region_revisit = -Config.LAMBDA_LOCAL_REGION_REVISIT * idle_gate * local_recent_revisit_score * old_reg_scale
        r_path_inefficiency = 0.0
        if Config.LAMBDA_PATH_INEFFICIENCY > 0.0:
            r_path_inefficiency = (
                -Config.LAMBDA_PATH_INEFFICIENCY
                * idle_gate
                * max(0.0, float(Config.PATH_EFF_THR) - path_efficiency)
                * old_reg_scale
            )
        loop_closure_score = max(loop_closure_short, loop_closure_mid)
        r_loop_closure = 0.0
        if Config.LAMBDA_LOOP_CLOSURE > 0.0:
            r_loop_closure = -Config.LAMBDA_LOOP_CLOSURE * idle_gate * loop_closure_score * old_reg_scale
        # 抓视野级区域内反复画圈，而不是简单回头一步。
        r_region_loop = 0.0
        if Config.LAMBDA_REGION_LOOP > 0.0:
            region_loop_score = self._compute_region_loop_score(current_pos=(hero_x_idx, hero_z_idx))
            r_region_loop = -Config.LAMBDA_REGION_LOOP * idle_gate * region_loop_score

        r_flash_skip_near_treasure = 0.0
        r_flash_interrupted = 0.0
        r_buff_approach = 0.0
        target_buff_ready_score = float(target_buff_info["ready_score"]) if target_buff_info is not None else 0.0
        target_buff_dist_norm = float(target_buff_info["dist_norm"]) if target_buff_info is not None else 1.0
        target_buff_key = target_buff_info["key"] if target_buff_info is not None else None
        treasure_scarcity = float(target_buff_info["treasure_scarcity"]) if target_buff_info is not None else 0.0
        if (
            Config.LAMBDA_BUFF_APPROACH > 0.0
            and target_buff_info is not None
            and self.prev_target_buff_exists
            and self.prev_target_buff_key == target_buff_key
        ):
            r_buff_approach = (
                Config.LAMBDA_BUFF_APPROACH
                * effective_pressure_score
                * treasure_scarcity
                * target_buff_ready_score
                * max(self.prev_target_buff_dist_norm - target_buff_dist_norm, 0.0)
            )
        treasure_reward_info = self._compute_treasure_rewards(
            target_treasure=target_treasure,
            treasure_guidance=treasure_guidance,
            current_treasures=current_treasures,
            last_treasures_before_update=last_treasures_before_update,
            current_buffs=current_buffs,
            last_buffs_before_update=last_buffs_before_update,
            env_threat_score=raw_threat_score,
            greed_pressure_score=effective_pressure_score,
            local_open_score=local_open_score,
        )
        r_treasure_collect = float(treasure_reward_info["r_treasure_collect"])
        r_treasure_approach = float(treasure_reward_info["r_treasure_approach"])
        r_treasure_guidance = float(treasure_reward_info["r_treasure_guidance"])
        r_treasure_conflict_penalty = float(treasure_reward_info["r_treasure_conflict_penalty"])
        r_treasure_backtrack = float(treasure_reward_info["r_treasure_backtrack"])
        r_treasure_commit = float(treasure_reward_info["r_treasure_commit"])
        r_treasure_miss_close = float(treasure_reward_info["r_treasure_miss_close"])
        scaled_new_area = float(
            math.log1p(float(Config.EXPLORE_NEW_REACHABLE_LOG_ALPHA) * new_reachable_road_ratio)
            / math.log1p(float(Config.EXPLORE_NEW_REACHABLE_LOG_ALPHA))
        )
        r_new_visible_area = 0.0
        if Config.LAMBDA_NEW_VISIBLE > 0.0 and explore_hard_gate > 0.0:
            r_new_visible_area = Config.LAMBDA_NEW_VISIBLE * scaled_new_area
        r_hidden_explore = 0.0
        if (
            Config.LAMBDA_HIDDEN_EXPLORE > 0.0
            and explore_hard_gate > 0.0
            and 0 <= last_action <= 7
        ):
            best_frontier = float(np.max(frontier_dir_score)) if len(frontier_dir_score) > 0 else 0.0
            if best_frontier >= Config.HIDDEN_EXPLORE_MIN_FRONTIER:
                act_frontier = float(frontier_dir_score[last_action])
                act_frontier_norm = act_frontier / max(best_frontier, 1e-6)
                if act_frontier_norm >= 1.0 - Config.HIDDEN_EXPLORE_BEST_MARGIN:
                    # 没有可见目标时，鼓励朝更未知的方向推进。
                    r_hidden_explore = Config.LAMBDA_HIDDEN_EXPLORE * act_frontier_norm
        r_explore_progress = 0.0
        if Config.LAMBDA_EXPLORE_PROGRESS > 0.0 and 0 <= last_action <= 7:
            r_explore_progress = Config.LAMBDA_EXPLORE_PROGRESS * float(self.prev_explore_dir_gain[last_action])
        r_target_approach = 0.0
        if (
            Config.LAMBDA_TARGET_APPROACH > 0.0
            and target_resource is not None
            and self.prev_target_resource_exists
            and bool(target_resource["walk_reachable_flag"])
            and self.prev_target_walk_reachable
        ):
            r_target_approach = (
                Config.LAMBDA_TARGET_APPROACH
                * (1.0 - effective_pressure_score)
                * max(self.prev_target_path_dist_norm - float(target_resource["walk_path_len_norm"]), 0.0)
            )
        r_flash_overshoot_resource = 0.0

        selected_idx = last_action - 8 if 8 <= last_action <= 15 else -1
        actual_pressure_delta = 0.0
        if 0 <= selected_idx < 8:
            selected_flash_range = float(max(self.prev_flash_dir_actual_range[selected_idx], 1.0))
            self.prev_selected_flash_range = selected_flash_range
            actual_pressure_delta = float(np.clip(prev_flash_pressure - flash_decision_pressure, -1.0, 1.0))

            actual_resource_gain = (
                Config.FLASH_PATH_TREASURE_WEIGHT * float(delta_treasure) / max(float(runtime_cfg["treasure_count"]), 1.0)
                + Config.FLASH_PATH_BUFF_WEIGHT * float(delta_buff) / max(float(runtime_cfg["buff_count"]), 1.0)
            )
            current_dead = local_deadend_risk
            prev_dead = 1.0 - self.prev_local_open_score
            pressure_gate = float(np.clip(prev_flash_pressure, 0.0, 1.0) ** Config.FLASH_ESCAPE_PRESSURE_BETA)
            best_walk_pressure_after, _, _ = self._compute_best_walk_pressure_after(
                map_info=map_info,
                hero_pos=hero_pos,
                monsters=monsters,
                legal_action=base_legal_action,
                time_to_monster2_ratio=time_to_monster2_ratio,
                time_to_monster_speedup_ratio=time_to_monster_speedup_ratio,
                is_flash_avail=is_flash_avail,
                has_buff=has_buff,
                runtime_cfg=runtime_cfg,
            )
            necessity_raw = float(best_walk_pressure_after - flash_decision_pressure - Config.FLASH_NECESSITY_MARGIN)
            flash_necessity = float(
                np.clip(necessity_raw / max(float(Config.FLASH_NECESSITY_SCALE), 1e-6), 0.0, 1.0)
            )
            replaceable_score = float(np.clip(1.0 - flash_necessity, 0.0, 1.0))
            resource_relief = self._compute_flash_resource_relief(selected_idx, actual_resource_gain, target_resource)

            r_flash_escape = (
                Config.LAMBDA_FLASH_ESCAPE
                * pressure_gate
                * max(actual_pressure_delta, 0.0)
                * flash_necessity
            )
            r_flash_cross_wall = (
                Config.LAMBDA_FLASH_CROSS_WALL
                * float(self.prev_flash_dir_cross_wall_flag[selected_idx] > 0.0)
                * float(self.prev_flash_dir_reachable_ratio[selected_idx])
                * max(actual_pressure_delta, 0.0)
                * flash_necessity
            )
            r_flash_low_burn = (
                -Config.LAMBDA_FLASH_LOW_BURN
                * ((1.0 - prev_flash_pressure) ** Config.FLASH_LOW_BURN_POWER)
                * (1.0 - resource_relief)
                * replaceable_score
            )
            if Config.LAMBDA_FLASH_UNNECESSARY > 0.0:
                r_flash_unnecessary = (
                    -Config.LAMBDA_FLASH_UNNECESSARY
                    * replaceable_score
                    * float(actual_pressure_delta < Config.FLASH_PRESSURE_DELTA_MIN)
                )

            if Config.LAMBDA_FLASH_LANDING_BAD > 0.0:
                open_drop = self.prev_local_open_score - local_open_score
                deadend_rise = current_dead - prev_dead
                landing_bad = max(open_drop - Config.FLASH_LANDING_BAD_OPEN_DROP_THR, 0.0) + max(
                    deadend_rise - Config.FLASH_LANDING_BAD_DEADEND_RISE_THR,
                    0.0,
                )
                r_flash_landing_bad = -Config.LAMBDA_FLASH_LANDING_BAD * landing_bad

            if Config.LAMBDA_FLASH_SKIP_NEAR_TREASURE > 0.0:
                if (
                    near_treasure_collectability > Config.NEAR_TREASURE_COLLECT_THR
                    and delta_treasure == 0
                    and actual_pressure_delta < Config.FLASH_PRESSURE_DELTA_MIN
                ):
                    r_flash_skip_near_treasure = -Config.LAMBDA_FLASH_SKIP_NEAR_TREASURE

            if Config.LAMBDA_FLASH_INTERRUPTED > 0.0:
                flash_interrupted_ratio = float(1.0 - self.prev_flash_dir_reachable_ratio[selected_idx])
                if actual_pressure_delta < Config.FLASH_SAFE_GAIN_MIN_FOR_GOOD:
                    r_flash_interrupted = -Config.LAMBDA_FLASH_INTERRUPTED * flash_interrupted_ratio

            prev_target_collected = False
            if self.prev_target_resource_sub_type == 1:
                prev_target_collected = delta_treasure > 0
            elif self.prev_target_resource_sub_type == 2:
                prev_target_collected = delta_buff > 0

            if (
                self.prev_target_resource_exists
                and float(self.prev_flash_target_overshoot_risk[selected_idx]) > 0.0
                and actual_pressure_delta < Config.FLASH_PRESSURE_DELTA_MIN
                and not prev_target_collected
            ):
                r_flash_overshoot_resource = (
                    -Config.LAMBDA_FLASH_OVERSHOOT
                    * (1.0 - self.prev_effective_pressure_score)
                    * float(self.prev_flash_target_overshoot_risk[selected_idx])
                )
        else:
            self.prev_selected_flash_range = 1.0

        reward = (
            Config.LAMBDA_SURVIVE * r_survive
            + Config.LAMBDA_DANGER * r_danger
            + Config.LAMBDA_ESCAPE * r_escape
            + Config.LAMBDA_TREASURE * r_treasure
            + Config.LAMBDA_BUFF * r_buff
            + r_align
            + Config.LAMBDA_WALL * r_wall
            + r_flash_escape
            + r_flash_cross_wall
            + r_flash_low_burn
            + r_flash_unnecessary
            + r_flash_landing_bad
            + r_stall_no_progress_short
            + r_stall_no_progress_mid
            + r_recent_revisit
            + r_loop
            + r_frontier
            + r_local_region_revisit
            + r_path_inefficiency
            + r_loop_closure
            + r_region_loop
            + r_flash_skip_near_treasure
            + r_flash_interrupted
            + r_treasure_collect
            + r_treasure_approach
            + r_treasure_guidance
            + r_treasure_conflict_penalty
            + r_treasure_backtrack
            + r_treasure_commit
            + r_treasure_miss_close
            + r_new_visible_area
            + r_hidden_explore
            + r_explore_progress
            + r_buff_approach
            + r_target_approach
            + r_flash_overshoot_resource
        )

        # -------------------- reward 之后统一更新缓存 --------------------
        self.global_visit[hero_x_idx, hero_z_idx] += 1
        self.global_last_visit[hero_x_idx, hero_z_idx] = int(self.step_no)
        self.recent_positions.append((hero_x_idx, hero_z_idx))
        self.recent_positions_region.append((hero_x_idx, hero_z_idx))
        self.recent_positions_long.append((hero_x_idx, hero_z_idx))
        self.recent_step_distances.append(float(current_step_dist))

        self.last_min_monster_dist_raw_visible = cur_min_dist_raw_visible
        self.last_min_monster_dist_raw_all = cur_min_dist_raw_all
        self.last_treasures = current_treasures
        self.last_buffs = current_buffs
        self.last_hero_pos = {"x": hero_pos["x"], "z": hero_pos["z"]}

        self.prev_flash_dir_reachable_ratio = flash_direction_info["reachable_ratio"].copy()
        self.prev_flash_dir_cross_wall_flag = flash_direction_info["cross_wall_flag"].copy()
        self.prev_flash_dir_actual_range = flash_direction_info["actual_range"].copy()
        self.prev_flash_dir_path_resource_gain = flash_direction_info["path_resource_gain"].copy()
        self.prev_survive_pressure_score = survive_pressure_score
        self.prev_flash_decision_pressure = flash_decision_pressure
        self.prev_raw_threat_score = raw_threat_score
        self.prev_effective_pressure_score = effective_pressure_score
        self.prev_min_monster_reach_time_visible = cur_min_reach_time_visible
        self.prev_min_monster_reach_time_all = cur_min_reach_time_all
        self.prev_min_monster_reach_dist_visible = cur_min_reach_dist_visible
        self.prev_min_monster_reach_dist_all = cur_min_reach_dist_all
        self.prev_local_open_score = local_open_score
        self.prev_target_buff_value_score = float(target_buff_info["value_score"]) if target_buff_info is not None else 0.0
        self.prev_explore_dir_gain = explore_dir_gain.copy()
        # 兼容保留旧缓存名，但其语义已变为“新可达道路比例”而非“未知可见格比例”。
        self.prev_new_visible_unknown_ratio = new_reachable_road_ratio
        if target_treasure is not None:
            self.prev_target_treasure_exists = True
            self.prev_target_treasure_key = treasure_reward_info["target_key"]
            self.prev_target_treasure_path_dist_norm = float(treasure_reward_info["target_path_dist_norm"])
        else:
            self.prev_target_treasure_exists = False
            self.prev_target_treasure_key = None
            self.prev_target_treasure_path_dist_norm = 1.0
        if bool(treasure_guidance.get("treasure_guidance_exists", False)):
            self.prev_treasure_guidance_exists = True
            self.prev_treasure_guidance_dist_norm = float(treasure_reward_info["guidance_dist_norm"])
            self.prev_treasure_guidance_key = treasure_reward_info["guidance_key"]
        else:
            self.prev_treasure_guidance_exists = False
            self.prev_treasure_guidance_dist_norm = 1.0
            self.prev_treasure_guidance_key = None
        if target_buff_info is not None:
            self.prev_target_buff_exists = True
            self.prev_target_buff_key = target_buff_key
            self.prev_target_buff_dist_norm = target_buff_dist_norm
            self.prev_target_buff_ready_score = target_buff_ready_score
        else:
            self.prev_target_buff_exists = False
            self.prev_target_buff_key = None
            self.prev_target_buff_dist_norm = 1.0
            self.prev_target_buff_ready_score = 0.0
        if target_resource is not None:
            self.prev_target_resource_exists = True
            self.prev_target_resource_sub_type = int(target_resource["sub_type"])
            self.prev_target_resource_dist_norm = float(target_resource["dist_norm"])
            self.prev_target_resource_dir_vec = target_resource["dir_vec"].copy()
            self.prev_target_walk_reachable = bool(target_resource["walk_reachable_flag"])
            self.prev_target_flash_reachable = bool(target_resource["flash_reachable_flag"])
            self.prev_target_path_dist_norm = float(target_resource["walk_path_len_norm"])
            self.prev_target_line_blocked = float(target_resource["line_blocked_flag"])
        else:
            self.prev_target_resource_exists = False
            self.prev_target_resource_sub_type = 0
            self.prev_target_resource_dist_norm = 1.0
            self.prev_target_resource_dir_vec = np.zeros(2, dtype=np.float32)
            self.prev_target_walk_reachable = False
            self.prev_target_flash_reachable = False
            self.prev_target_path_dist_norm = 1.0
            self.prev_target_line_blocked = 0.0
        self.prev_flash_target_overshoot_risk = flash_target_overshoot_risk.copy()

        return feature, legal_action, [float(reward)]

#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright (c) 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Neural network model for Gorge Chase PPO.
"""

import torch
import torch.nn as nn

from agent_ppo.conf.conf import Config


def make_fc_layer(in_features, out_features):
    fc = nn.Linear(in_features, out_features)
    nn.init.orthogonal_(fc.weight.data)
    nn.init.zeros_(fc.bias.data)
    return fc


class Model(nn.Module):
    def __init__(self, device=None):
        super().__init__()
        self.model_name = "gorge_chase_v2"
        self.device = device

        input_dim = Config.DIM_OF_OBSERVATION
        action_num = Config.ACTION_NUM
        value_num = Config.VALUE_NUM

        actor_hidden_dim_1 = Config.ACTOR_HIDDEN_DIM_1
        actor_hidden_dim_2 = Config.ACTOR_HIDDEN_DIM_2
        critic_hidden_dim_1 = Config.CRITIC_HIDDEN_DIM_1
        critic_hidden_dim_2 = Config.CRITIC_HIDDEN_DIM_2

        # 隐藏层维度由 Config 按输入维度自动选择：
        # input_dim <= 260: 256 / 128
        # 260 < input_dim <= 340: 384 / 192
        # input_dim > 340: 512 / 256
        self.actor_net = nn.Sequential(
            make_fc_layer(input_dim, actor_hidden_dim_1),
            nn.ReLU(),
            make_fc_layer(actor_hidden_dim_1, actor_hidden_dim_2),
            nn.ReLU(),
            make_fc_layer(actor_hidden_dim_2, action_num),
        )

        self.critic_net = nn.Sequential(
            make_fc_layer(input_dim, critic_hidden_dim_1),
            nn.ReLU(),
            make_fc_layer(critic_hidden_dim_1, critic_hidden_dim_2),
            nn.ReLU(),
            make_fc_layer(critic_hidden_dim_2, value_num),
        )

    def forward(self, obs, inference=False):
        logits = self.actor_net(obs)
        value = self.critic_net(obs)
        return logits, value

    def set_train_mode(self):
        self.train()

    def set_eval_mode(self):
        self.eval()

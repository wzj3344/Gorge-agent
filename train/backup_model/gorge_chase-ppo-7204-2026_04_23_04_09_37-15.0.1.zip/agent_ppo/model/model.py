#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright (c) 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Neural network model for Gorge Chase PPO.
"""

import torch
import torch.nn as nn

from agent_ppo.conf.conf import Config


def make_fc_layer(in_features, out_features):
    fc = nn.Linear(in_features, out_features)
    nn.init.orthogonal_(fc.weight.data)
    nn.init.zeros_(fc.bias.data)
    return fc


class MapEncoderCNN(nn.Module):
    def __init__(self, out_dim=32):
        super().__init__()
        # 输入: (B, 1, 21, 21) -> 输出: (B, out_dim)
        self.conv = nn.Sequential(
            nn.Conv2d(1, 8, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(8, 16, kernel_size=3, stride=2, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=1),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),
        )
        self.fc = nn.Linear(32, out_dim)
        for module in self.conv:
            if isinstance(module, nn.Conv2d):
                nn.init.orthogonal_(module.weight.data)
                nn.init.zeros_(module.bias.data)
        nn.init.orthogonal_(self.fc.weight.data)
        nn.init.zeros_(self.fc.bias.data)

    def forward(self, x):
        h = self.conv(x)
        h = h.flatten(1)
        z = self.fc(h)
        return z


class Model(nn.Module):
    def __init__(self, device=None):
        super().__init__()
        self.model_name = "gorge_chase_v2"
        self.device = device

        action_num = Config.ACTION_NUM
        value_num = Config.VALUE_NUM

        self.map_encoder = MapEncoderCNN(out_dim=Config.MAP_EMBED_DIM)
        # 共享骨干: [手工特征, 地图 embedding] -> hidden
        self.shared_net = nn.Sequential(
            make_fc_layer(Config.MODEL_INPUT_DIM, Config.SHARED_HIDDEN_DIM_1),
            nn.ReLU(),
            make_fc_layer(Config.SHARED_HIDDEN_DIM_1, Config.SHARED_HIDDEN_DIM_2),
            nn.ReLU(),
        )
        self.actor_head = make_fc_layer(Config.SHARED_HIDDEN_DIM_2, action_num)
        self.critic_head = make_fc_layer(Config.SHARED_HIDDEN_DIM_2, value_num)

    def forward(self, obs, map_feature, inference=False):
        del inference
        if map_feature.dim() == 2:
            map_feature = map_feature.view(-1, 1, Config.RAW_MAP_SIZE, Config.RAW_MAP_SIZE)
        map_embed = self.map_encoder(map_feature)
        fused = torch.cat([obs, map_embed], dim=1)
        hidden = self.shared_net(fused)
        logits = self.actor_head(hidden)
        value = self.critic_head(hidden)
        return logits, value

    def set_train_mode(self):
        self.train()

    def set_eval_mode(self):
        self.eval()

#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Feature preprocessor and reward design for Gorge Chase PPO.
峡谷追猎 PPO 特征预处理与奖励设计。
"""

import numpy as np

MAX_MONSTER_SPEED = 5.0
MAX_FLASH_CD = 2000.0
MAX_BUFF_DURATION = 500.0

MAP_SIDE = 128
VISION_HALF = 10  # 21×21 视野：中心向各方向 10 格

# 移动动作 0–7 的 (dx, dz)，与 x 轴向右、z 轴向下一致：0东 1东北 2北 3西北 4西 5西南 6南 7东南
ACTION_DX = np.array([1.0, 1.0, 0.0, -1.0, -1.0, -1.0, 0.0, 1.0], dtype=np.float64)
ACTION_DZ = np.array([0.0, -1.0, -1.0, -1.0, 0.0, 1.0, 1.0, 1.0], dtype=np.float64)

# 本步新揭示格子奖励系数（避免首帧过大，对单步揭示量做温和缩放）
lambda_EXPLORATION_NEW_CELL_COEF = 0.002

# === 官方协议 1-8 方位映射表 (转为 x,z 单位方向向量) ===
DIR_MAP = {
    0: (0.0, 0.0),          # 重叠/无效
    1: (1.0, 0.0),          # 东
    2: (0.707, 0.707),      # 东北
    3: (0.0, 1.0),          # 北
    4: (-0.707, 0.707),     # 西北
    5: (-1.0, 0.0),         # 西
    6: (-0.707, -0.707),    # 西南
    7: (0.0, -1.0),         # 南
    8: (0.707, -0.707)      # 东南
}

def _norm(v, v_max, v_min=0.0):
    v = float(np.clip(v, v_min, v_max))
    return (v - v_min) / (v_max - v_min) if (v_max - v_min) > 1e-6 else 0.0


def _update_vision_and_count_new(unexplored, hx, hz):
    """将以 (hx,hz) 为中心的 (2*VISION_HALF+1)^2 视野标为已探索(0)，返回本步新揭示格子数。"""
    new_count = 0
    x0 = max(0, hx - VISION_HALF)
    x1 = min(MAP_SIDE - 1, hx + VISION_HALF)
    z0 = max(0, hz - VISION_HALF)
    z1 = min(MAP_SIDE - 1, hz + VISION_HALF)
    for gx in range(x0, x1 + 1):
        for gz in range(z0, z1 + 1):
            if unexplored[gx, gz] != 0:
                new_count += 1
                unexplored[gx, gz] = 0
    return new_count

class Preprocessor:
    def __init__(self):
        self.reset()

    def reset(self):
        self.step_no = 0
        self.max_step = 1000
        self.last_min_monster_dist_raw = None
        self.last_hero_pos = None
        self.last_score = 0.0
        self.last_buff_time = 0.0
        self.last_treasures = 0
        self.last_buffs = 0
        # 全局探索图：1=从未进入过视野，0=曾进入过视野
        self._unexplored = np.ones((MAP_SIDE, MAP_SIDE), dtype=np.uint8)
        self._last_explore_dir_feat = np.zeros(8, dtype=np.float32)

    def feature_process(self, env_obs, last_action):
        observation = env_obs["observation"]
        frame_state = observation["frame_state"]
        env_info = observation["env_info"]
        map_info = observation["map_info"]
        legal_act_raw = observation["legal_action"]

        self.step_no = observation["step_no"]
        self.max_step = env_info.get("max_step", 1000)
        current_score = env_info.get("total_score", 0.0)

        # 1. 英雄自身特征 (6D)
        hero = frame_state["heroes"]
        hero_pos = hero["pos"]
        hero_x_norm = _norm(hero_pos["x"], 128.0)
        hero_z_norm = _norm(hero_pos["z"], 128.0)
        
        flash_cd = hero.get("flash_cooldown", 0)
        flash_cd_norm = _norm(flash_cd, MAX_FLASH_CD)
        is_flash_avail = 1.0 if flash_cd == 0 else 0.0
        
        buff_time = hero.get("buff_remaining_time", 0)
        buff_remain_norm = _norm(buff_time, MAX_BUFF_DURATION)
        has_buff = 1.0 if buff_time > 0 else 0.0

        hero_feat = np.array([hero_x_norm, hero_z_norm, flash_cd_norm, buff_remain_norm, is_flash_avail, has_buff], dtype=np.float32)

        # 2. 怪物特征 (5D x 2) -> 混合判定：在视野内用坐标，在视野外用方向桶
        monsters = frame_state.get("monsters",[])
        monster_feats = []
        raw_dists =[]
        for i in range(2):
            if i < len(monsters):
                m = monsters[i]
                is_in_view = float(m.get("is_in_view", 0))
                m_speed_norm = _norm(m.get("speed", 1), MAX_MONSTER_SPEED)
                
                if is_in_view:
                    # 视野内：精准坐标
                    m_pos = m["pos"]
                    dx = m_pos["x"] - hero_pos["x"]
                    dz = m_pos["z"] - hero_pos["z"]
                    dx_norm = np.clip(dx / 40.0, -1.0, 1.0)
                    dz_norm = np.clip(dz / 40.0, -1.0, 1.0)
                    raw_dist = np.sqrt(dx**2 + dz**2)
                    dist_norm = np.clip(raw_dist / 40.0, 0.0, 1.0)
                else:
                    # 视野外：用方向和桶估算
                    direction = m.get("hero_relative_direction", 0)
                    bucket = m.get("hero_l2_distance", 5)
                    dir_vec = DIR_MAP.get(direction, (0.0, 0.0))
                    
                    dx_norm = dir_vec[0]
                    dz_norm = dir_vec[1]
                    raw_dist = bucket * 30.0 + 15.0 # 取桶的中间值估算距离
                    dist_norm = np.clip(raw_dist / 40.0, 0.0, 1.0)
                
                monster_feats.append(np.array([is_in_view, dx_norm, dz_norm, m_speed_norm, dist_norm], dtype=np.float32))
                raw_dists.append(raw_dist)
            else:
                monster_feats.append(np.zeros(5, dtype=np.float32))
                raw_dists.append(100.0)

        # 3. 局部地图特征 (11x11 = 121D)
        map_feat = np.zeros(121, dtype=np.float32)
        if map_info is not None and len(map_info) > 0:
            center = len(map_info) // 2
            flat_idx = 0
            for row in range(center - 5, center + 6):
                for col in range(center - 5, center + 6):
                    if 0 <= row < len(map_info) and 0 <= col < len(map_info[0]):
                        map_feat[flat_idx] = float(map_info[row][col] != 0)
                    flat_idx += 1
                    
        # 4. 8方向射线探路防卡墙 (8D)
        ray_feat = np.zeros(8, dtype=np.float32)
        if map_info is not None and len(map_info) > 0:
            center = len(map_info) // 2
            dirs =[(0,1), (-1,1), (-1,0), (-1,-1), (0,-1), (1,-1), (1,0), (1,1)]
            max_ray = 10.0
            for i, (dr, dc) in enumerate(dirs):
                dist = 0.0
                r, c = center, center
                for _ in range(int(max_ray)):
                    r += dr
                    c += dc
                    if 0 <= r < len(map_info) and 0 <= c < len(map_info[0]):
                        if map_info[r][c] == 0: 
                            break
                        dist += 1.0
                    else:
                        break
                ray_feat[i] = dist / max_ray
                
        # 5. 罗盘雷达 (直接读取方位与距离桶) 
        organs = frame_state.get("organs",[])
        
        treasure_exist = 0.0  
        t_dx_norm, t_dz_norm = 0.0, 0.0
        t_dist_bucket = 5.0
        t_direction = 0  # 记录最近宝箱的方向编号，算奖励时用
        min_t_bucket = 999

        buff_exist = 0.0      
        b_dx_norm, b_dz_norm = 0.0, 0.0
        b_dist_bucket = 5.0
        min_b_bucket = 999

        for organ in organs:
            if organ.get("status", 1) != 1:
                continue
                
            # 直接从协议取罗盘数据！不取 pos！
            direction = organ.get("hero_relative_direction", 0)
            bucket = organ.get("hero_l2_distance", 5)
            dir_vec = DIR_MAP.get(direction, (0.0, 0.0))
            
            if organ.get("sub_type") == 1: # 宝箱
                treasure_exist = 1.0
                if bucket < min_t_bucket:
                    min_t_bucket = bucket
                    t_direction = direction
                    t_dx_norm = dir_vec[0]
                    t_dz_norm = dir_vec[1]
                    t_dist_bucket = bucket
                    
            elif organ.get("sub_type") == 2: # Buff
                buff_exist = 1.0
                if bucket < min_b_bucket:
                    min_b_bucket = bucket
                    b_dx_norm = dir_vec[0]
                    b_dz_norm = dir_vec[1]
                    b_dist_bucket = bucket

        # 桶编号归一化 (0-5 除以 5.0)
        t_dist_norm = t_dist_bucket / 5.0 if treasure_exist > 0 else 1.0
        b_dist_norm = b_dist_bucket / 5.0 if buff_exist > 0 else 1.0

        treasure_feat = np.array([treasure_exist, t_dx_norm, t_dz_norm, t_dist_norm], dtype=np.float32)
        buff_feat = np.array([buff_exist, b_dx_norm, b_dz_norm, b_dist_norm], dtype=np.float32)
        

        # 6. 合法动作掩码 (16D)
        legal_action = [1] * 16
        if isinstance(legal_act_raw, list) and legal_act_raw:
            if isinstance(legal_act_raw[0], bool):
                for j in range(min(16, len(legal_act_raw))):
                    legal_action[j] = int(legal_act_raw[j])
            else:
                valid_set = {int(a) for a in legal_act_raw if int(a) < 16}
                legal_action =[1 if j in valid_set else 0 for j in range(16)]

        if sum(legal_action) == 0:
            legal_action = [1] * 16

        # 7. 进度特征 (2D)
        step_norm = _norm(self.step_no, self.max_step)
        progress_feat = np.array([step_norm, step_norm], dtype=np.float32)

        # 8. 全局探索：更新 128×128 视野覆盖，并计算八方向未探索引导权重 (8D)
        hx_i = int(np.clip(round(hero_pos["x"]), 0, MAP_SIDE - 1))
        hz_i = int(np.clip(round(hero_pos["z"]), 0, MAP_SIDE - 1))
        new_cells_in_vision = _update_vision_and_count_new(self._unexplored, hx_i, hz_i)

        # 9. 拼接所有特征 (Total: 179D)
        feature = np.concatenate([
                hero_feat, monster_feats[0], monster_feats[1],
                map_feat, ray_feat, treasure_feat, buff_feat,
                np.array(legal_action, dtype=np.float32), progress_feat,
            ])

        # ==================== 奖励函数 (Reward Shaping) ====================
        reward = 0.01  # 存活基础分

        cur_min_dist_raw = 100.0
        for i in range(2):
            if monster_feats[i][0] > 0:
                cur_min_dist_raw = min(cur_min_dist_raw, raw_dists[i])

        # 1. 危险距离惩罚
        if cur_min_dist_raw < 3.0:
            reward -= 0.5
        elif cur_min_dist_raw < 6.0:
            reward -= 0.2

        # 2. 逃避距离引导
        if self.last_min_monster_dist_raw is not None and cur_min_dist_raw < 25.0:
            dist_diff = cur_min_dist_raw - self.last_min_monster_dist_raw
            dist_diff = np.clip(dist_diff, -3.0, 3.0)
            reward += dist_diff * 0.05
        self.last_min_monster_dist_raw = cur_min_dist_raw

        # 3. 宝箱与Buff核心奖励
        current_treasures = env_info.get("treasures_collected", 0)
        current_buffs = env_info.get("collected_buff", 0)

        if current_treasures > self.last_treasures:
            reward += 20.0  
        self.last_treasures = current_treasures

        if current_buffs > self.last_buffs:
            reward += 10.0  
        self.last_buffs = current_buffs

        # 4. 寻宝“方位罗盘”引导 (向量点乘机制)
        if treasure_exist > 0 and self.last_hero_pos is not None:
            # 英雄本步真实的移动向量
            h_dx = hero_pos["x"] - self.last_hero_pos["x"]
            h_dz = hero_pos["z"] - self.last_hero_pos["z"]
            
            # 宝箱的单位方向向量
            target_dir = DIR_MAP.get(t_direction, (0.0, 0.0))
            
            # 向量点乘：判断移动方向是否与宝箱方向一致
            alignment = h_dx * target_dir[0] + h_dz * target_dir[1]
            
            # 限制极值（防止闪现刷分），奖励系数 0.05
            alignment = np.clip(alignment, -2.0, 2.0)
            reward += alignment * 0.05  
        

        # 5. 撞墙惩罚
        if self.last_hero_pos is not None:
            dx = hero_pos["x"] - self.last_hero_pos["x"]
            dz = hero_pos["z"] - self.last_hero_pos["z"]
            if dx == 0 and dz == 0 and 0 <= last_action <= 7:
                reward -= 0.2
        self.last_hero_pos = hero_pos

        # 6. 闪现技能引导
        if 8 <= last_action <= 15:
            if cur_min_dist_raw > 15.0:
                reward -= 0.5  
            else:
                reward += 0.5  

        # 7. 探索奖励：本步新进入视野的格子数 
        reward += lambda_EXPLORATION_NEW_CELL_COEF * float(min(new_cells_in_vision,50))

        return feature, legal_action, [reward]
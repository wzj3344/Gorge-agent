#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Configuration for Gorge Chase PPO.
峡谷追猎 PPO 配置。
"""


class Config:
    # Feature dimensions (共171维)
    FEATURES =[
        6,                            # 1. 英雄自身特征 (6D)
        5,                            # 2. 怪物1特征 (5D)
        5,                            # 3. 怪物2特征 (5D)
        121,                          # 4. 局部地图网格 (121D)
        8,                            # 5. 防撞墙射线 (8D)
        4,                            # 6. 宝箱雷达 (4D)  
        4,                            # 7. Buff雷达 (4D)  
        16,                           # 8. 合法动作掩码 (16D)
        2,                            # 9. 游戏进度 (2D)
    ]
    FEATURE_SPLIT_SHAPE = FEATURES
    FEATURE_LEN = sum(FEATURE_SPLIT_SHAPE)
    DIM_OF_OBSERVATION = FEATURE_LEN

    # Action space / 动作空间：8个移动方向 + 8个闪现方向
    ACTION_NUM = 16

    # Value head / 价值头
    VALUE_NUM = 1

    # PPO hyperparameters / PPO 超参数
    GAMMA = 0.995             # 视野范围拉长，考虑到最高1000步
    LAMDA = 0.95
    INIT_LEARNING_RATE_START = 0.0003
    BETA_START = 0.01         # 提高初始熵，鼓励多尝试闪现和吃宝箱
    CLIP_PARAM = 0.2
    VF_COEF = 1.0
    GRAD_CLIP_RANGE = 0.5
